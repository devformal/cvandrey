document.addEventListener('DOMContentLoaded', () => {
    const expItems = document.querySelectorAll('.exp-item');
    const timelineProgress = document.querySelector('.timeline-progress');
    
    // Добавляем индексы для анимации
    expItems.forEach((item, index) => {
        item.style.setProperty('--item-index', index);
    });

    // Наблюдатель для анимации появления
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.2,
        rootMargin: '50px'
    });

    expItems.forEach(item => observer.observe(item));
    
    const updateTimelineProgress = () => {
        const activeItems = document.querySelectorAll('.exp-item.active');
        if (activeItems.length > 0) {
            const lastActive = activeItems[activeItems.length - 1];
            const items = Array.from(expItems);
            const index = items.indexOf(lastActive);
            const progress = ((index + 1) / items.length) * 100;
            
            // Плавная анимация прогресса
            timelineProgress.style.setProperty('--progress', `${progress}%`);
        }
    };
    
    expItems.forEach(item => {
        const header = item.querySelector('.exp-header');
        const details = item.querySelector('.exp-details');
        
        header.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Плавное закрытие других элементов
            expItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    const otherDetails = otherItem.querySelector('.exp-details');
                    otherDetails.style.maxHeight = '0';
                    otherDetails.style.opacity = '0';
                    setTimeout(() => {
                        otherItem.classList.remove('active');
                    }, 300);
                }
            });
            
            // Переключение текущего элемента
            if (!isActive) {
                item.classList.add('active');
                details.style.maxHeight = `${details.scrollHeight}px`;
                details.style.opacity = '1';
                
                // Анимация прогресс-баров
                const bars = item.querySelectorAll('.progress-fill');
                bars.forEach(bar => {
                    const value = bar.parentElement.dataset.value;
                    setTimeout(() => {
                        bar.style.width = `${value}%`;
                    }, 300);
                });
            } else {
                details.style.maxHeight = '0';
                details.style.opacity = '0';
                setTimeout(() => {
                    item.classList.remove('active');
                }, 300);
            }
            
            updateTimelineProgress();
        });

        // Обработка наведения
        header.addEventListener('mouseenter', () => {
            const logo = header.querySelector('.exp-logo');
            logo.style.transform = 'scale(1.1)';
        });

        header.addEventListener('mouseleave', () => {
            const logo = header.querySelector('.exp-logo');
            logo.style.transform = 'scale(1)';
        });
    });

    // Открываем текущее место работы по умолчанию
    const currentJob = document.querySelector('.exp-item.current');
    if (currentJob) {
        currentJob.classList.add('active');
        const details = currentJob.querySelector('.exp-details');
        details.style.maxHeight = `${details.scrollHeight}px`;
        details.style.opacity = '1';
        
        const bars = currentJob.querySelectorAll('.progress-fill');
        bars.forEach(bar => {
            const value = bar.parentElement.dataset.value;
            setTimeout(() => {
                bar.style.width = `${value}%`;
            }, 300);
        });
        
        updateTimelineProgress();
    }

    // Обновление высоты при изменении размера окна
    window.addEventListener('resize', () => {
        const activeItem = document.querySelector('.exp-item.active');
        if (activeItem) {
            const details = activeItem.querySelector('.exp-details');
            details.style.maxHeight = `${details.scrollHeight}px`;
        }
    });

    // Инициализация аккордеона
    const timelineItems = document.querySelectorAll('.timeline-item');
    const timelineHeaders = document.querySelectorAll('.timeline-header');

    // Функция для анимации прогресс-баров
    const animateProgressBars = (container) => {
        const progressBars = container.querySelectorAll('.progress-bar');
        progressBars.forEach(bar => {
            const progress = bar.style.getPropertyValue('--progress');
            bar.style.width = '0%';
            setTimeout(() => {
                bar.style.width = progress;
            }, 100);
        });
    };

    // Обработчик клика по заголовку
    timelineHeaders.forEach((header, index) => {
        header.addEventListener('click', () => {
            const item = timelineItems[index];
            const isActive = item.classList.contains('active');
            
            // Закрываем все элементы
            timelineItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('active');
                }
            });

            // Переключаем текущий элемент
            item.classList.toggle('active');

            // Если элемент стал активным, анимируем прогресс-бары
            if (!isActive) {
                const content = item.querySelector('.timeline-content');
                setTimeout(() => {
                    animateProgressBars(content);
                }, 300);
            }
        });
    });

    // Анимация прогресс-баров при первой загрузке
    const activeItem = document.querySelector('.timeline-item.active');
    if (activeItem) {
        setTimeout(() => {
            animateProgressBars(activeItem);
        }, 500);
    }

    // Добавляем эффект наведения для карточек
    const cards = document.querySelectorAll('.achievement-card, .responsibility-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateX(8px)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateX(0)';
        });
    });

    // Анимация появления метрик
    const metricObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                metricObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '50px'
    });

    const metricBoxes = document.querySelectorAll('.metric-box');
    metricBoxes.forEach((box, index) => {
        box.style.opacity = '0';
        box.style.transform = 'translateY(20px)';
        box.style.transitionDelay = `${index * 100}ms`;
        metricObserver.observe(box);
    });
}); 