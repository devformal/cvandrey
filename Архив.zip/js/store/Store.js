export class Store {
    constructor(app) {
        this.app = app;
        this.state = {};
        this.reducers = new Map();
        this.middlewares = [];
        this.subscribers = new Set();
        
        this.init();
    }

    init() {
        // Регистрируем основные редьюсеры
        this.registerReducers({
            theme: this.themeReducer,
            locale: this.localeReducer,
            ui: this.uiReducer,
            user: this.userReducer
        });

        // Добавляем middleware
        this.use(this.loggerMiddleware);
        this.use(this.storageMiddleware);
        this.use(this.analyticsMiddleware);

        // Инициализируем начальное состояние
        this.initializeState();
    }

    registerReducers(reducers) {
        Object.entries(reducers).forEach(([key, reducer]) => {
            this.reducers.set(key, reducer.bind(this));
        });
    }

    use(middleware) {
        this.middlewares.push(middleware.bind(this));
    }

    async dispatch(action) {
        try {
            // Применяем middleware
            const chain = this.middlewares.map(middleware => middleware(action));
            await Promise.all(chain);

            // Находим нужный редьюсер
            const [namespace] = action.type.split('/');
            const reducer = this.reducers.get(namespace);

            if (!reducer) {
                throw new Error(`No reducer found for namespace: ${namespace}`);
            }

            // Получаем новое состояние
            const newState = reducer(this.state[namespace], action);
            const oldState = this.state[namespace];

            // Обновляем состояние
            this.state = {
                ...this.state,
                [namespace]: newState
            };

            // Уведомляем подписчиков
            this.notify(namespace, newState, oldState);

        } catch (error) {
            this.app.logger.log('error', 'Store dispatch error:', error);
            throw error;
        }
    }

    subscribe(callback) {
        this.subscribers.add(callback);
        return () => this.subscribers.delete(callback);
    }

    notify(namespace, newState, oldState) {
        this.subscribers.forEach(callback => {
            try {
                callback(namespace, newState, oldState);
            } catch (error) {
                this.app.logger.log('error', 'Store subscriber error:', error);
            }
        });
    }

    // Редьюсеры
    themeReducer(state = this.app.config.get('theme.defaultTheme'), action) {
        switch (action.type) {
            case 'theme/set':
                return action.payload;
            case 'theme/toggle':
                return state === 'light' ? 'dark' : 'light';
            default:
                return state;
        }
    }

    localeReducer(state = this.app.config.get('i18n.defaultLocale'), action) {
        switch (action.type) {
            case 'locale/set':
                return action.payload;
            default:
                return state;
        }
    }

    uiReducer(state = { loading: false, error: null }, action) {
        switch (action.type) {
            case 'ui/setLoading':
                return { ...state, loading: action.payload };
            case 'ui/setError':
                return { ...state, error: action.payload };
            case 'ui/reset':
                return { loading: false, error: null };
            default:
                return state;
        }
    }

    // Middleware
    async loggerMiddleware(action) {
        if (this.app.config.get('app.environment') === 'development') {
            console.log('Action:', action);
            console.log('State before:', this.state);
        }
    }

    async storageMiddleware(action) {
        // Сохраняем определенные части состояния в localStorage
        const persistentActions = ['theme/set', 'locale/set'];
        if (persistentActions.includes(action.type)) {
            const [namespace] = action.type.split('/');
            const storageKey = this.app.config.getStorageKey(namespace);
            localStorage.setItem(storageKey, JSON.stringify(action.payload));
        }
    }

    async analyticsMiddleware(action) {
        // Отправляем события в аналитику
        if (this.app.config.get('app.environment') === 'production') {
            this.app.analytics?.trackEvent('state_change', {
                action: action.type,
                payload: action.payload
            });
        }
    }

    initializeState() {
        // Загружаем сохраненные значения
        const theme = localStorage.getItem(this.app.config.getStorageKey('theme'));
        const locale = localStorage.getItem(this.app.config.getStorageKey('locale'));

        this.state = {
            theme: theme || this.app.config.get('theme.defaultTheme'),
            locale: locale || this.app.config.get('i18n.defaultLocale'),
            ui: { loading: false, error: null },
            user: null
        };
    }
} 