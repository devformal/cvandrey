import { App } from './App.js';

// Инициализация приложения после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.app = new App();
});

// Обработка горячей замены модулей в development
if (process.env.NODE_ENV === 'development' && module.hot) {
    module.hot.accept('./App', () => {
        window.app.destroy();
        window.app = new App();
    });
} 