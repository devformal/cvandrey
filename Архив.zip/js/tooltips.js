const skillItems = document.querySelectorAll('.skill-item');

skillItems.forEach(item => {
    const tooltip = document.createElement('div');
    tooltip.className = 'skill-tooltip';
    tooltip.textContent = item.dataset.description;
    
    item.addEventListener('mouseenter', () => {
        item.appendChild(tooltip);
        setTimeout(() => tooltip.classList.add('show'), 10);
    });
    
    item.addEventListener('mouseleave', () => {
        tooltip.classList.remove('show');
        setTimeout(() => tooltip.remove(), 200);
    });
}); 