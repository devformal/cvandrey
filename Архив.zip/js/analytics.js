// Analytics configuration
const ANALYTICS_CONFIG = {
    trackingId: 'UA-XXXXXXXXX-X', // Замените на ваш ID Google Analytics
    enableWebVitals: true,
    enableUserMetrics: true
};

// Core Web Vitals tracking
const reportWebVitals = ({ name, delta, id }) => {
    gtag('event', name, {
        event_category: 'Web Vitals',
        event_label: id,
        value: Math.round(name === 'CLS' ? delta * 1000 : delta),
        non_interaction: true,
    });
};

// User interaction tracking
class Analytics {
    static init() {
        this.setupGoogleAnalytics();
        this.trackUserInteractions();
        this.trackPerformanceMetrics();
    }

    static setupGoogleAnalytics() {
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());
        gtag('config', ANALYTICS_CONFIG.trackingId);
    }

    static trackUserInteractions() {
        // Track clicks on navigation links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                gtag('event', 'navigation_click', {
                    event_category: 'Navigation',
                    event_label: e.target.textContent
                });
            });
        });

        // Track skill category changes
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                gtag('event', 'skill_filter', {
                    event_category: 'Skills',
                    event_label: e.target.dataset.filter
                });
            });
        });

        // Track theme changes
        document.getElementById('themeToggle').addEventListener('click', () => {
            const theme = document.documentElement.getAttribute('data-theme');
            gtag('event', 'theme_change', {
                event_category: 'Theme',
                event_label: theme
            });
        });
    }

    static trackPerformanceMetrics() {
        // Performance metrics
        if (window.performance) {
            const timing = window.performance.timing;
            const loadTime = timing.loadEventEnd - timing.navigationStart;
            
            gtag('event', 'page_load', {
                event_category: 'Performance',
                event_label: 'Load Time',
                value: loadTime
            });
        }

        // Track scroll depth
        let maxScroll = 0;
        window.addEventListener('scroll', () => {
            const scrollPercent = Math.round((window.scrollY + window.innerHeight) / 
                document.documentElement.scrollHeight * 100);
            
            if (scrollPercent > maxScroll) {
                maxScroll = scrollPercent;
                if (maxScroll % 25 === 0) { // Track at 25%, 50%, 75%, 100%
                    gtag('event', 'scroll_depth', {
                        event_category: 'Engagement',
                        event_label: `${maxScroll}%`,
                        non_interaction: true
                    });
                }
            }
        });
    }

    // Custom event tracking
    static trackEvent(category, action, label = null, value = null) {
        gtag('event', action, {
            event_category: category,
            event_label: label,
            value: value
        });
    }
}

// Initialize analytics when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    Analytics.init();
});

// Export for use in other modules
export { Analytics, reportWebVitals }; 