// Простая инициализация темы
const initTheme = () => {
    document.documentElement.setAttribute('data-theme', 'light');
};

// Максимально упрощенное переключение темы
const toggleTheme = () => {
    const html = document.documentElement;
    if (html.getAttribute('data-theme') === 'light') {
        html.setAttribute('data-theme', 'dark');
    } else {
        html.setAttribute('data-theme', 'light');
    }
};

// Упрощенная анимация навыков
const animateSkills = () => {
    const skills = document.querySelectorAll('.skill-progress');
    skills.forEach(skill => {
        skill.style.setProperty('--progress', `${skill.dataset.percent}%`);
    });
};

// Упрощенная фильтрация
const initSkillsFilter = () => {
    const buttons = document.querySelectorAll('.filter-btn');
    const categories = document.querySelectorAll('.skill-category');

    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            const filter = btn.dataset.filter;
            buttons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            categories.forEach(cat => {
                if (filter === 'all' || cat.classList.contains(filter)) {
                    cat.style.display = 'block';
                } else {
                    cat.style.display = 'none';
                }
            });
        });
    });
};

// Упрощенные обработчики событий
const handleEvents = () => {
    document.addEventListener('click', (e) => {
        const target = e.target;
        
        if (target.closest('.button')) {
            target.closest('.button').classList.add('active');
        }
        
        if (target.closest('.card')) {
            target.closest('.card').classList.add('hover');
        }
    });
};

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Переключение темы
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
        });
    }

    // Базовые функции
    animateSkills();
    initSkillsFilter();
    handleEvents();
}); 