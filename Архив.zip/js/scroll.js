document.addEventListener('DOMContentLoaded', () => {
    const grid = document.querySelector('.research-grid');
    const dots = document.querySelectorAll('.scroll-dot');
    
    const updateDots = () => {
        const scrollPercentage = grid.scrollLeft / (grid.scrollWidth - grid.clientWidth);
        const activeIndex = Math.round(scrollPercentage * (dots.length - 1));
        
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === activeIndex);
        });
    };

    grid.addEventListener('scroll', updateDots);

    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            targetSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        });
    });

    const scrollProgress = document.querySelector('.scroll-progress');
    let lastScrollTop = 0;
    let scrollTimeout;
    let rafId;

    const updateProgress = () => {
        const winScroll = window.pageYOffset || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (winScroll / height) * 100;
        
        scrollProgress.style.setProperty('--scroll-width', `${scrolled}%`);

        // Определяем скорость скролла
        const scrollSpeed = Math.abs(winScroll - lastScrollTop);
        lastScrollTop = winScroll;

        // Добавляем класс при быстром скролле
        if (scrollSpeed > 30) {
            scrollProgress.classList.add('fast-scroll');
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                scrollProgress.classList.remove('fast-scroll');
            }, 150);
        }

        rafId = requestAnimationFrame(updateProgress);
    };

    // Запускаем анимацию
    updateProgress();

    // Очищаем анимацию при необходимости
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            cancelAnimationFrame(rafId);
        } else {
            updateProgress();
        }
    });
}); 