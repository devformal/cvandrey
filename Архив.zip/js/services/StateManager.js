export class StateManager {
    constructor() {
        this.validators = new Map();
        this.persistentKeys = new Set();
        this.listeners = new Map();

        // Создаем прокси с расширенной функциональностью
        this.state = new Proxy({}, {
            set: (target, property, value) => {
                // Проверяем валидатор
                if (this.validators.has(property)) {
                    const validator = this.validators.get(property);
                    if (!validator(value)) {
                        console.warn(`Invalid value for ${property}:`, value);
                        return false;
                    }
                }

                const oldValue = target[property];
                target[property] = value;

                // Сохраняем в localStorage если свойство персистентное
                if (this.persistentKeys.has(property)) {
                    try {
                        localStorage.setItem(property, JSON.stringify(value));
                    } catch (e) {
                        console.error('Failed to persist state:', e);
                    }
                }

                // Уведомляем подписчиков
                this.notify(property, value, oldValue);
                return true;
            },

            get: (target, property) => {
                // Пытаемся получить значение из localStorage для персистентных свойств
                if (this.persistentKeys.has(property) && !(property in target)) {
                    try {
                        const value = localStorage.getItem(property);
                        if (value !== null) {
                            target[property] = JSON.parse(value);
                        }
                    } catch (e) {
                        console.error('Failed to retrieve persisted state:', e);
                    }
                }
                return target[property];
            }
        });
    }

    // Добавляем валидатор для свойства
    addValidator(property, validator) {
        this.validators.set(property, validator);
    }

    // Делаем свойство персистентным
    makePersistent(property) {
        this.persistentKeys.add(property);
    }

    subscribe(property, callback) {
        if (!this.listeners.has(property)) {
            this.listeners.set(property, new Set());
        }
        this.listeners.get(property).add(callback);

        // Возвращаем функцию отписки
        return () => this.listeners.get(property).delete(callback);
    }

    notify(property, newValue, oldValue) {
        if (this.listeners.has(property)) {
            this.listeners.get(property).forEach(callback => {
                try {
                    callback(newValue, oldValue);
                } catch (error) {
                    console.error(`Error in state listener for ${property}:`, error);
                }
            });
        }
    }

    // Получить снимок текущего состояния
    getSnapshot() {
        return JSON.parse(JSON.stringify(this.state));
    }

    // Восстановить состояние из снимка
    restore(snapshot) {
        Object.entries(snapshot).forEach(([key, value]) => {
            this.state[key] = value;
        });
    }
} 