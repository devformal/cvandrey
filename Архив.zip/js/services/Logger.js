export class Logger {
    static levels = {
        ERROR: 0,
        WARN: 1,
        INFO: 2,
        DEBUG: 3
    };

    constructor(options = {}) {
        this.level = options.level || Logger.levels.INFO;
        this.prefix = options.prefix || '[App]';
        this.enabled = options.enabled !== false;
        this.storage = new Map();
    }

    log(level, message, ...args) {
        if (!this.enabled || level > this.level) return;

        const timestamp = new Date().toISOString();
        const formattedMessage = `${this.prefix} [${timestamp}] ${message}`;

        switch (level) {
            case Logger.levels.ERROR:
                console.error(formattedMessage, ...args);
                this.store('error', { message, args, timestamp });
                break;
            case Logger.levels.WARN:
                console.warn(formattedMessage, ...args);
                this.store('warn', { message, args, timestamp });
                break;
            case Logger.levels.INFO:
                console.info(formattedMessage, ...args);
                this.store('info', { message, args, timestamp });
                break;
            case Logger.levels.DEBUG:
                console.debug(formattedMessage, ...args);
                this.store('debug', { message, args, timestamp });
                break;
        }
    }

    store(level, data) {
        if (!this.storage.has(level)) {
            this.storage.set(level, []);
        }
        this.storage.get(level).push(data);
        
        // Ограничиваем количество хранимых логов
        if (this.storage.get(level).length > 1000) {
            this.storage.get(level).shift();
        }
    }

    getLogs(level) {
        return this.storage.get(level) || [];
    }
} 