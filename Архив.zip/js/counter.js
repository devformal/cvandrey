document.addEventListener('DOMContentLoaded', () => {
    const statValues = document.querySelectorAll('.stat-value');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const value = entry.target;
                const endValue = parseInt(value.dataset.value);
                animateValue(value, 0, endValue, 1500);
                observer.unobserve(value);
            }
        });
    }, {
        threshold: 0.5
    });

    function animateValue(element, start, end, duration) {
        let current = start;
        const range = end - start;
        const increment = range / (duration / 16);
        const startTime = performance.now();

        function update(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            current = start + (range * progress);
            element.textContent = Math.floor(current) + (element.dataset.suffix || '');

            if (progress < 1) {
                requestAnimationFrame(update);
            }
        }

        requestAnimationFrame(update);
    }

    statValues.forEach(value => {
        value.dataset.value = value.textContent.replace(/\D/g, '');
        value.dataset.suffix = value.textContent.replace(/[0-9]/g, '');
        observer.observe(value);
    });
}); 