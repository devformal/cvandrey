document.addEventListener('DOMContentLoaded', () => {
    const categories = document.querySelectorAll('.skill-category');
    
    categories.forEach(category => {
        const button = category.querySelector('.expand-btn');
        
        button.addEventListener('click', () => {
            // Close other categories
            categories.forEach(otherCategory => {
                if (otherCategory !== category) {
                    otherCategory.classList.remove('expanded');
                }
            });
            
            // Toggle current category
            category.classList.toggle('expanded');
        });
    });

    const skillItems = document.querySelectorAll('.skill-item[role="button"]');
    
    // Обработка клика/нажатия Enter
    skillItems.forEach(item => {
        item.addEventListener('click', toggleSkillDetails);
        item.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                toggleSkillDetails.call(item);
            }
        });
    });

    function toggleSkillDetails() {
        const isExpanded = this.getAttribute('aria-expanded') === 'true';
        
        // Закрываем другие открытые детали
        skillItems.forEach(otherItem => {
            if (otherItem !== this && otherItem.getAttribute('aria-expanded') === 'true') {
                otherItem.setAttribute('aria-expanded', 'false');
            }
        });
        
        // Переключаем текущий элемент
        this.setAttribute('aria-expanded', !isExpanded);
    }

    // Анимация при скролле
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                
                // Анимируем элементы внутри категории
                const items = entry.target.querySelectorAll('.tool-item, .lang-item');
                items.forEach((item, index) => {
                    setTimeout(() => {
                        item.classList.add('visible');
                    }, index * 100);
                });
                
                // Отключаем наблюдение после появления
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.2,
        rootMargin: '50px'
    });

    const skillItems = document.querySelectorAll('.skill-item');
    
    skillItems.forEach(item => {
        // Анимация при скролле
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    item.classList.add('visible');
                }
            });
        }, { threshold: 0.5 });
        
        observer.observe(item);
    });

    // Обработка раскрытия деталей инструментов
    const expandableTools = document.querySelectorAll('.tool-item.expandable');
    
    expandableTools.forEach(tool => {
        const expandBtn = tool.querySelector('.expand-btn');
        const details = tool.querySelector('.tool-details');
        
        if (expandBtn && details) {
            expandBtn.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Закрываем другие открытые детали
                expandableTools.forEach(otherTool => {
                    if (otherTool !== tool && otherTool.classList.contains('expanded')) {
                        otherTool.classList.remove('expanded');
                        const otherDetails = otherTool.querySelector('.tool-details');
                        if (otherDetails) {
                            otherDetails.style.maxHeight = '0';
                            otherDetails.style.opacity = '0';
                        }
                    }
                });
                
                // Переключаем текущий элемент
                const isExpanding = !tool.classList.contains('expanded');
                tool.classList.toggle('expanded');
                
                // Плавная анимация
                if (isExpanding) {
                    details.style.display = 'block';
                    details.style.maxHeight = details.scrollHeight + 'px';
                    details.style.opacity = '1';
                } else {
                    details.style.maxHeight = '0';
                    details.style.opacity = '0';
                    setTimeout(() => {
                        if (!tool.classList.contains('expanded')) {
                            details.style.display = 'none';
                        }
                    }, 300);
                }
            });
        }
    });

    // Анимация появления при скролле
    const animateOnScroll = () => {
        const categories = document.querySelectorAll('.tools-category, .languages-category');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    
                    // Анимируем элементы внутри категории
                    const items = entry.target.querySelectorAll('.tool-item, .lang-item');
                    items.forEach((item, index) => {
                        setTimeout(() => {
                            item.classList.add('visible');
                        }, index * 100);
                    });
                    
                    // Отключаем наблюдение после появления
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.2,
            rootMargin: '50px'
        });

        categories.forEach(category => {
            observer.observe(category);
        });
    };

    // Запускаем анимации
    animateOnScroll();

    // Анимация прогресс-баров при скролле
    const progressBars = document.querySelectorAll('.skill-progress');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const bar = entry.target.querySelector('.progress-bar');
                bar.style.transform = `scaleX(${bar.parentElement.getAttribute('aria-valuenow') / 100})`;
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    progressBars.forEach(bar => observer.observe(bar));

    // Фильтрация и поиск
    const searchInput = document.getElementById('skillSearch');
    const filterBtns = document.querySelectorAll('.filter-btn');
    const skillItems = document.querySelectorAll('.skill-item');

    // Функция фильтрации
    function filterSkills() {
        const searchTerm = searchInput.value.toLowerCase();
        const activeFilter = document.querySelector('.filter-btn.active').dataset.filter;

        skillItems.forEach(item => {
            const name = item.querySelector('.skill-name').textContent.toLowerCase();
            const level = item.querySelector('.skill-badge').textContent.toLowerCase();
            const desc = item.querySelector('.skill-description').textContent.toLowerCase();

            const matchesSearch = name.includes(searchTerm) || desc.includes(searchTerm);
            const matchesFilter = activeFilter === 'all' || level.includes(activeFilter);

            item.style.display = matchesSearch && matchesFilter ? '' : 'none';
        });
    }

    // Обработчики фильтров
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterSkills();
        });
    });

    // Обработчик поиска
    searchInput.addEventListener('input', filterSkills);

    // Добавляем тултипы с дополнительной информацией
    skillItems.forEach(item => {
        const name = item.querySelector('.skill-name').textContent;
        const level = item.querySelector('.skill-badge').textContent;
        item.setAttribute('data-tooltip', `${name} - ${level}`);
    });

    // Lazy loading для деталей навыков
    const loadSkillDetails = (item) => {
        if (!item.hasAttribute('data-loaded')) {
            item.classList.add('loading');
            
            // Имитация загрузки данных
            setTimeout(() => {
                item.classList.remove('loading');
                item.setAttribute('data-loaded', 'true');
            }, 500);
        }
    };

    skillItems.forEach(item => {
        item.addEventListener('mouseenter', () => loadSkillDetails(item));
    });

    // Добавляем анимацию при загрузке
    skillItems.forEach((item, index) => {
        item.style.opacity = '0';
        item.style.transform = 'scale(0.8)';
        setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'scale(1)';
        }, index * 50);
    });

    // Раскрытие карточек навыков
    skillItems.forEach(item => {
        item.addEventListener('click', () => {
            // Закрываем все остальные карточки в той же категории
            const category = item.closest('.skill-category');
            category.querySelectorAll('.skill-item').forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('expanded');
                }
            });

            // Переключаем текущую карточку
            item.classList.toggle('expanded');
        });
    });

    // Инициализация прогресс-баров
    skillItems.forEach(item => {
        const progressBar = item.querySelector('.skill-progress-bar');
        if (progressBar) {
            const currentTransform = progressBar.style.transform;
            progressBar.setAttribute('data-progress', currentTransform);
            progressBar.style.transform = 'scaleX(0)';
        }
    });

    // Инициализация уровней навыков
    initializeSkillLevels();
    
    // Инициализация фильтров
    initializeFilters();
    
    // Анимация при скролле
    initializeScrollAnimations();

    // Добавляем новые функции для интерактивности

    // Анимация тултипов для иконок инструментов
    initializeToolTips();

    // Анимация прогресс-баров при скролле
    initializeProgressBars();

    // Анимация фильтров
    animateFilterTransition();

    // Анимация достижений
    initializeAchievements();

    // Параллакс эффект для иконок категорий
    initializeParallax();

    // Улучшенные анимации для секции навыков
    animateCircularProgress();
    
    // Добавляем плавное появление при загрузке
    setTimeout(() => {
        document.querySelector('.skills-section').classList.add('visible');
    }, 300);
});

function initializeSkillLevels() {
    const skillItems = document.querySelectorAll('.skill-item[data-level]');
    
    skillItems.forEach(item => {
        const level = item.getAttribute('data-level');
        const levelBar = item.querySelector('.level-bar');
        
        if (levelBar) {
            levelBar.style.setProperty('--level', '0%');
            setTimeout(() => {
                levelBar.style.setProperty('--level', `${level}%`);
            }, 500);
        }
    });
}

function initializeFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const skillCategories = document.querySelectorAll('.skill-category');

    // Показываем первую категорию по умолчанию
    document.querySelector('[data-filter="core"]').classList.add('active');
    document.querySelector('[data-category="core"]').style.display = 'block';

    // Скрываем остальные категории
    skillCategories.forEach(category => {
        if (category.dataset.category !== 'core') {
            category.style.display = 'none';
        }
    });

    // Простое переключение категорий
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const filter = btn.dataset.filter;
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            skillCategories.forEach(category => {
                category.style.display = 
                    category.dataset.category === filter ? 'block' : 'none';
            });
        });
    });
}

function initializeScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                
                // Анимация прогресс-баров
                const levelBars = entry.target.querySelectorAll('.level-bar');
                levelBars.forEach((bar, index) => {
                    setTimeout(() => {
                        const level = bar.closest('.skill-item').getAttribute('data-level');
                        bar.style.setProperty('--level', `${level}%`);
                    }, index * 100);
                });
                
                // Анимация достижений
                const achievements = entry.target.querySelectorAll('.achievement');
                achievements.forEach((achievement, index) => {
                    setTimeout(() => {
                        achievement.style.opacity = '1';
                        achievement.style.transform = 'translateY(0)';
                    }, index * 100);
                });
                
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.2,
        rootMargin: '50px'
    });

    document.querySelectorAll('.skill-category').forEach(category => {
        observer.observe(category);
    });
}

function initializeToolTips() {
    const toolIcons = document.querySelectorAll('.tool-icon');
    
    toolIcons.forEach(icon => {
        const tooltip = document.createElement('div');
        tooltip.className = 'tool-tooltip';
        tooltip.textContent = icon.getAttribute('title');
        
        icon.addEventListener('mouseenter', () => {
            document.body.appendChild(tooltip);
            const iconRect = icon.getBoundingClientRect();
            
            tooltip.style.left = `${iconRect.left + (iconRect.width / 2)}px`;
            tooltip.style.top = `${iconRect.top - 10}px`;
            
            requestAnimationFrame(() => {
                tooltip.classList.add('visible');
                tooltip.style.transform = 'translate(-50%, -100%) scale(1)';
            });
        });
        
        icon.addEventListener('mouseleave', () => {
            tooltip.style.transform = 'translate(-50%, -100%) scale(0.9)';
            tooltip.classList.remove('visible');
            setTimeout(() => tooltip.remove(), 200);
        });
    });
}

function initializeProgressBars() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const skillItem = entry.target;
                const level = skillItem.getAttribute('data-level');
                const levelBar = skillItem.querySelector('.level-bar');
                
                if (levelBar) {
                    requestAnimationFrame(() => {
                        levelBar.style.setProperty('--level', `${level}%`);
                        levelBar.classList.add('animated');
                    });
                }
            }
        });
    }, {
        threshold: 0.5
    });

    document.querySelectorAll('.skill-item').forEach(item => {
        observer.observe(item);
    });
}

function initializeAchievements() {
    const achievements = document.querySelectorAll('.achievement');
    
    achievements.forEach(achievement => {
        achievement.style.opacity = '0';
        achievement.style.transform = 'translateY(20px)';
        
        achievement.addEventListener('mouseenter', () => {
            achievement.style.transform = 'translateY(-4px) scale(1.05)';
            achievement.style.background = 'rgba(65, 105, 225, 0.1)';
            achievement.style.boxShadow = '0 4px 12px rgba(65, 105, 225, 0.15)';
        });
        
        achievement.addEventListener('mouseleave', () => {
            achievement.style.transform = 'translateY(0) scale(1)';
            achievement.style.background = 'rgba(65, 105, 225, 0.05)';
            achievement.style.boxShadow = 'none';
        });
    });
}

function initializeParallax() {
    const categoryIcons = document.querySelectorAll('.category-icon-wrapper');
    
    document.addEventListener('mousemove', (e) => {
        requestAnimationFrame(() => {
            const { clientX, clientY } = e;
            const centerX = window.innerWidth / 2;
            const centerY = window.innerHeight / 2;
            
            categoryIcons.forEach(icon => {
                const rect = icon.getBoundingClientRect();
                const iconCenterX = rect.left + (rect.width / 2);
                const iconCenterY = rect.top + (rect.height / 2);
                
                const deltaX = (clientX - centerX) * 0.02;
                const deltaY = (clientY - centerY) * 0.02;
                const rotation = Math.atan2(deltaY, deltaX) * (180 / Math.PI);
                
                icon.style.transform = `
                    translate(${deltaX}px, ${deltaY}px)
                    rotate(${rotation * 0.1}deg)
                    scale(${1 + Math.abs(deltaX + deltaY) * 0.001})
                `;
            });
        });
    });
}

function animateCircularProgress() {
    const circle = document.querySelector('.circular-chart .circle');
    const percentage = document.querySelector('.circular-chart .percentage');
    
    if (circle && percentage) {
        const percentValue = 90;
        const circumference = 2 * Math.PI * 15.9155;
        
        circle.style.strokeDasharray = '0 ' + circumference;
        percentage.textContent = '0%';
        
        setTimeout(() => {
            circle.style.strokeDasharray = `${circumference * percentValue / 100} ${circumference}`;
            
            let currentPercent = 0;
            const duration = 2000;
            const increment = percentValue / (duration / 16);
            
            const updatePercentage = () => {
                if (currentPercent < percentValue) {
                    currentPercent += increment;
                    percentage.textContent = `${Math.round(currentPercent)}%`;
                    requestAnimationFrame(updatePercentage);
                } else {
                    percentage.textContent = `${percentValue}%`;
                }
            };
            
            requestAnimationFrame(updatePercentage);
        }, 500);
    }
}

// Анимация фильтров
function animateFilterTransition(oldFilter, newFilter) {
    const categories = document.querySelectorAll('.skill-category');
    
    categories.forEach(category => {
        if (newFilter === 'all' || category.getAttribute('data-category') === newFilter) {
            category.style.transform = 'scale(0.9)';
            category.style.opacity = '0';
            
            setTimeout(() => {
                category.style.display = 'block';
                requestAnimationFrame(() => {
                    category.style.transform = 'scale(1)';
                    category.style.opacity = '1';
                });
            }, 300);
        } else {
            category.style.transform = 'scale(0.9)';
            category.style.opacity = '0';
            
            setTimeout(() => {
                category.style.display = 'none';
            }, 300);
        }
    });
}

// Debounce функция для оптимизации поиска
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
} 