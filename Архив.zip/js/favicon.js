// Создаем анимированный favicon
function createAnimatedFavicon() {
    const canvas = document.createElement('canvas');
    canvas.width = 32;
    canvas.height = 32;
    const ctx = canvas.getContext('2d');
    
    // Создаем градиентный фон
    const gradient = ctx.createLinearGradient(0, 0, 32, 32);
    gradient.addColorStop(0, '#2563EB');    // Основной синий
    gradient.addColorStop(0.5, '#4F46E5');  // Индиго
    gradient.addColorStop(1, '#6366F1');    // Фиолетовый

    let hue = 0;
    let angle = 0;

    function animate() {
        // Очищаем canvas
        ctx.clearRect(0, 0, 32, 32);

        // Обновляем градиент с анимацией
        const rotatedGradient = ctx.createLinearGradient(
            16 + Math.cos(angle) * 16,
            16 + Math.sin(angle) * 16,
            16 - Math.cos(angle) * 16,
            16 - Math.sin(angle) * 16
        );

        rotatedGradient.addColorStop(0, `hsl(${hue}, 80%, 60%)`);
        rotatedGradient.addColorStop(0.5, `hsl(${hue + 40}, 80%, 60%)`);
        rotatedGradient.addColorStop(1, `hsl(${hue + 80}, 80%, 60%)`);

        // Рисуем фон
        ctx.fillStyle = rotatedGradient;
        ctx.beginPath();
        ctx.arc(16, 16, 16, 0, Math.PI * 2);
        ctx.fill();

        // Добавляем свечение
        ctx.shadowColor = `hsl(${hue}, 80%, 60%)`;
        ctx.shadowBlur = 8;

        // Рисуем текст с градиентом
        const textGradient = ctx.createLinearGradient(8, 8, 24, 24);
        textGradient.addColorStop(0, '#FFFFFF');
        textGradient.addColorStop(1, '#F8FAFC');

        ctx.fillStyle = textGradient;
        ctx.font = 'bold 16px SF Pro Display, -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Добавляем эффект пульсации
        const scale = 1 + Math.sin(angle * 2) * 0.05;
        ctx.save();
        ctx.translate(16, 16);
        ctx.scale(scale, scale);
        ctx.fillText('AN', 0, 0);
        ctx.restore();

        // Обновляем favicon
        updateFavicon(canvas.toDataURL('image/png'));

        // Обновляем анимацию
        hue = (hue + 0.5) % 360;
        angle = (angle + 0.02) % (Math.PI * 2);
        requestAnimationFrame(animate);
    }

    function updateFavicon(dataUrl) {
        let link = document.querySelector('link[rel="shortcut icon"]');
        if (!link) {
            link = document.createElement('link');
            link.rel = 'shortcut icon';
            document.head.appendChild(link);
        }
        link.type = 'image/x-icon';
        link.href = dataUrl;
    }

    // Добавляем оптимизацию для производительности
    let isTabVisible = true;
    let animationFrame;

    document.addEventListener('visibilitychange', () => {
        isTabVisible = document.visibilityState === 'visible';
        if (isTabVisible) {
            animate();
        } else {
            cancelAnimationFrame(animationFrame);
            // Устанавливаем статичную версию favicon при неактивной вкладке
            ctx.clearRect(0, 0, 32, 32);
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, 32, 32);
            ctx.fillStyle = '#FFFFFF';
            ctx.fillText('AN', 16, 16);
            updateFavicon(canvas.toDataURL('image/png'));
        }
    });

    // Добавляем поддержку темной темы
    const darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    function updateColors() {
        const isDarkMode = darkModeMediaQuery.matches;
        gradient.addColorStop(0, isDarkMode ? '#60A5FA' : '#2563EB');
        gradient.addColorStop(0.5, isDarkMode ? '#818CF8' : '#4F46E5');
        gradient.addColorStop(1, isDarkMode ? '#A78BFA' : '#6366F1');
    }
    
    darkModeMediaQuery.addListener(updateColors);
    updateColors();

    // Запускаем анимацию
    animate();
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', createAnimatedFavicon); 