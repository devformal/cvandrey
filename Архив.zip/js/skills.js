document.addEventListener('DOMContentLoaded', () => {
    const categories = document.querySelectorAll('.skill-category');
    
    categories.forEach(category => {
        const button = category.querySelector('.expand-btn');
        
        button.addEventListener('click', () => {
            // Close other categories
            categories.forEach(otherCategory => {
                if (otherCategory !== category) {
                    otherCategory.classList.remove('expanded');
                }
            });
            
            // Toggle current category
            category.classList.toggle('expanded');
        });
    });

    const skillItems = document.querySelectorAll('.skill-item[role="button"]');
    
    // Используем делегирование событий
    document.addEventListener('click', (e) => {
        const target = e.target;
        
        // Обработка клика по кнопке категории
        if (target.closest('.expand-btn')) {
            const category = target.closest('.skill-category');
            categories.forEach(cat => {
                if (cat !== category) cat.classList.remove('expanded');
            });
            category.classList.toggle('expanded');
        }
        
        // Обработка клика по навыку
        if (target.closest('.skill-item')) {
            const item = target.closest('.skill-item');
            const category = item.closest('.skill-category');
            
            category.querySelectorAll('.skill-item').forEach(otherItem => {
                if (otherItem !== item) otherItem.classList.remove('expanded');
            });
            item.classList.toggle('expanded');
        }
    });

    // Оптимизация анимаций
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                requestAnimationFrame(() => {
                    entry.target.classList.add('visible');
                });
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    // Наблюдаем за элементами
    document.querySelectorAll('.skill-item, .tool-item, .lang-item')
        .forEach(item => observer.observe(item));

    // Обработка раскрытия деталей инструментов
    const expandableTools = document.querySelectorAll('.tool-item.expandable');
    
    expandableTools.forEach(tool => {
        const expandBtn = tool.querySelector('.expand-btn');
        const details = tool.querySelector('.tool-details');
        
        if (expandBtn && details) {
            expandBtn.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Закрываем другие открытые детали
                expandableTools.forEach(otherTool => {
                    if (otherTool !== tool && otherTool.classList.contains('expanded')) {
                        otherTool.classList.remove('expanded');
                        const otherDetails = otherTool.querySelector('.tool-details');
                        if (otherDetails) {
                            otherDetails.style.maxHeight = '0';
                            otherDetails.style.opacity = '0';
                        }
                    }
                });
                
                // Переключаем текущий элемент
                const isExpanding = !tool.classList.contains('expanded');
                tool.classList.toggle('expanded');
                
                // Плавная анимация
                if (isExpanding) {
                    details.style.display = 'block';
                    details.style.maxHeight = details.scrollHeight + 'px';
                    details.style.opacity = '1';
                } else {
                    details.style.maxHeight = '0';
                    details.style.opacity = '0';
                    setTimeout(() => {
                        if (!tool.classList.contains('expanded')) {
                            details.style.display = 'none';
                        }
                    }, 300);
                }
            });
        }
    });

    // Анимация появления при скролле
    const animateOnScroll = () => {
        const categories = document.querySelectorAll('.tools-category, .languages-category');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    
                    // Анимируем элементы внутри категории
                    const items = entry.target.querySelectorAll('.tool-item, .lang-item');
                    items.forEach((item, index) => {
                        setTimeout(() => {
                            item.classList.add('visible');
                        }, index * 100);
                    });
                    
                    // Отключаем наблюдение после появления
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.2,
            rootMargin: '50px'
        });

        categories.forEach(category => {
            observer.observe(category);
        });
    };

    // Запускаем анимации
    animateOnScroll();

    // Анимация прогресс-баров при скролле
    const progressBars = document.querySelectorAll('.skill-progress');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const bar = entry.target.querySelector('.progress-bar');
                bar.style.transform = `scaleX(${bar.parentElement.getAttribute('aria-valuenow') / 100})`;
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    progressBars.forEach(bar => observer.observe(bar));

    // Фильтрация и поиск
    const searchInput = document.getElementById('skillSearch');
    const filterBtns = document.querySelectorAll('.filter-btn');

    // Функция фильтрации
    function filterSkills() {
        const searchTerm = searchInput.value.toLowerCase();
        const activeFilter = document.querySelector('.filter-btn.active').dataset.filter;

        skillItems.forEach(item => {
            const name = item.querySelector('.skill-name').textContent.toLowerCase();
            const level = item.querySelector('.skill-badge').textContent.toLowerCase();
            const desc = item.querySelector('.skill-description').textContent.toLowerCase();

            const matchesSearch = name.includes(searchTerm) || desc.includes(searchTerm);
            const matchesFilter = activeFilter === 'all' || level.includes(activeFilter);

            item.style.display = matchesSearch && matchesFilter ? '' : 'none';
        });
    }

    // Обработчики фильтров
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterSkills();
        });
    });

    // Обработчик поиска
    searchInput.addEventListener('input', filterSkills);

    // Удаляем блок lazy loading для деталей навыков
    skillItems.forEach(item => {
        const name = item.querySelector('.skill-name').textContent;
        const level = item.querySelector('.skill-badge').textContent;
        item.setAttribute('data-tooltip', `${name} - ${level}`);
    });

    // Добавляем анимацию при загрузке
    skillItems.forEach((item, index) => {
        item.style.opacity = '0';
        item.style.transform = 'scale(0.8)';
        setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'scale(1)';
        }, index * 50);
    });

    // Инициализация прогресс-баров
    skillItems.forEach(item => {
        const progressBar = item.querySelector('.skill-progress-bar');
        if (progressBar) {
            const currentTransform = progressBar.style.transform;
            progressBar.setAttribute('data-progress', currentTransform);
            progressBar.style.transform = 'scaleX(0)';
        }
    });
});

// Debounce функция для оптимизации поиска
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
} 