document.addEventListener('DOMContentLoaded', () => {
    const filterBtns = document.querySelectorAll('.publications-filter .filter-btn');
    const publicationCards = document.querySelectorAll('.publication-card');

    // Фильтрация публикаций
    function filterPublications(filter) {
        publicationCards.forEach(card => {
            const categories = card.dataset.categories.split(' ');
            if (filter === 'all' || categories.includes(filter)) {
                card.style.display = 'block';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 50);
            } else {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300);
            }
        });
    }

    // Обработчики фильтров
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterPublications(btn.dataset.filter);
        });
    });

    // Раскрытие деталей публикации
    publicationCards.forEach(card => {
        card.addEventListener('click', () => {
            const wasExpanded = card.classList.contains('expanded');
            
            // Закрываем другие карточки
            publicationCards.forEach(otherCard => {
                if (otherCard !== card) {
                    otherCard.classList.remove('expanded');
                }
            });

            // Переключаем текущую карточку
            card.classList.toggle('expanded', !wasExpanded);
        });
    });

    // Анимация статистики при раскрытии
    const statValues = document.querySelectorAll('.publication-stats .stat-value');
    
    function animateValue(element, start, end, duration) {
        let current = start;
        const range = end - start;
        const increment = range / (duration / 16);
        const startTime = performance.now();

        function update(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            current = start + (range * progress);
            element.textContent = Math.floor(current);

            if (progress < 1) {
                requestAnimationFrame(update);
            }
        }

        requestAnimationFrame(update);
    }

    // Наблюдаем за появлением статистики
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const value = entry.target;
                const endValue = parseInt(value.textContent);
                animateValue(value, 0, endValue, 1000);
                observer.unobserve(value);
            }
        });
    });

    statValues.forEach(value => observer.observe(value));
}); 