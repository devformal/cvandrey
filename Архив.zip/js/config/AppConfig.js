export class AppConfig {
    constructor() {
        this.config = {
            app: {
                name: 'Linguist Profile',
                version: '1.0.0',
                environment: process.env.NODE_ENV || 'development',
                baseUrl: process.env.BASE_URL || 'https://your-domain.com',
                apiUrl: process.env.API_URL || 'https://api.your-domain.com'
            },

            i18n: {
                defaultLocale: 'en',
                fallbackLocale: 'en',
                supportedLocales: ['en', 'ru'],
                localesPath: '/locales'
            },

            theme: {
                defaultTheme: 'system',
                supportedThemes: ['light', 'dark', 'system'],
                colorSchemes: {
                    light: {
                        primary: '#3B82F6',
                        secondary: '#6366F1',
                        accent: '#8B5CF6',
                        background: '#FFFFFF',
                        text: '#1F2937'
                    },
                    dark: {
                        primary: '#60A5FA',
                        secondary: '#818CF8',
                        accent: '#A78BFA',
                        background: '#0F172A',
                        text: '#F8FAFC'
                    }
                }
            },

            animations: {
                enabled: true,
                reducedMotion: false,
                defaultDuration: 300,
                defaultEasing: 'cubic-bezier(0.4, 0, 0.2, 1)',
                types: {
                    fadeIn: {
                        duration: 600,
                        easing: 'ease-out'
                    },
                    slideIn: {
                        duration: 400,
                        easing: 'ease-in-out'
                    }
                }
            },

            performance: {
                debounceDelay: 150,
                throttleDelay: 16,
                maxHistoryLength: 50,
                intersectionObserverThreshold: 0.2,
                intersectionObserverMargin: '50px'
            },

            seo: {
                siteName: 'Artem Novozhilov | Research Assistant',
                titleTemplate: '%s | Linguist Profile',
                defaultDescription: 'Research Assistant specializing in psycholinguistics and syntax',
                defaultImage: '/images/og-image.png',
                twitterHandle: '@your_handle'
            },

            features: {
                darkMode: true,
                animations: true,
                parallax: true,
                smoothScroll: true,
                lazyLoading: true
            },

            storage: {
                prefix: 'linguist_profile_',
                version: '1',
                ttl: 86400 // 24 hours
            },

            errors: {
                logLevel: process.env.NODE_ENV === 'development' ? 'debug' : 'error',
                reportToServer: process.env.NODE_ENV === 'production',
                ignoredErrors: [
                    'ResizeObserver loop limit exceeded'
                ]
            }
        };

        // Применяем переопределения из env
        this.applyEnvOverrides();
        
        // Делаем конфиг иммутабельным
        Object.freeze(this.config);
    }

    get(path) {
        return path.split('.').reduce((obj, key) => obj && obj[key], this.config);
    }

    applyEnvOverrides() {
        // Переопределяем значения из переменных окружения
        const envOverrides = {
            'app.name': process.env.APP_NAME,
            'app.baseUrl': process.env.BASE_URL,
            'i18n.defaultLocale': process.env.DEFAULT_LOCALE,
            'features.darkMode': process.env.ENABLE_DARK_MODE,
            'errors.logLevel': process.env.LOG_LEVEL
        };

        Object.entries(envOverrides).forEach(([path, value]) => {
            if (value !== undefined) {
                this.setNestedValue(this.config, path, value);
            }
        });
    }

    setNestedValue(obj, path, value) {
        const keys = path.split('.');
        const lastKey = keys.pop();
        const target = keys.reduce((obj, key) => obj[key] = obj[key] || {}, obj);
        target[lastKey] = value;
    }

    isFeatureEnabled(featureName) {
        return this.get(`features.${featureName}`) === true;
    }

    getStorageKey(key) {
        return `${this.get('storage.prefix')}${key}_v${this.get('storage.version')}`;
    }

    getThemeColors(theme) {
        return this.get(`theme.colorSchemes.${theme}`);
    }

    getAnimationConfig(type) {
        return this.get(`animations.types.${type}`) || this.get('animations.types.fadeIn');
    }
} 