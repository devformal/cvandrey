export class ScrollProgressController {
    constructor(app) {
        this.app = app;
        this.progress = app.domElements.scrollProgress;
        this.colors = this.generateColors();
        this.currentColorIndex = 0;
        
        this.init();
    }

    init() {
        this.setupProgressBar();
        this.bindEvents();
        this.startColorAnimation();
    }

    generateColors() {
        return [
            { ball: ['#3B82F6', '#6366F1'], trail: ['#60A5FA', '#818CF8'] },
            { ball: ['#8B5CF6', '#D946EF'], trail: ['#A78BFA', '#E879F9'] },
            { ball: ['#EC4899', '#F43F5E'], trail: ['#F472B6', '#FB7185'] },
            { ball: ['#10B981', '#059669'], trail: ['#34D399', '#10B981'] }
        ];
    }

    setupProgressBar() {
        this.progress.style.setProperty('--ball-color-1', this.colors[0].ball[0]);
        this.progress.style.setProperty('--ball-color-2', this.colors[0].ball[1]);
        this.progress.style.setProperty('--trail-color-1', this.colors[0].trail[0]);
        this.progress.style.setProperty('--trail-color-2', this.colors[0].trail[1]);
    }

    bindEvents() {
        this.app.state.subscribe('scrollProgress', (progress) => {
            this.updateProgress(progress);
        });

        let lastScrollTime = Date.now();
        let scrollTimeout;

        window.addEventListener('scroll', () => {
            const now = Date.now();
            const isFastScroll = now - lastScrollTime < 50;
            lastScrollTime = now;

            if (isFastScroll) {
                this.progress.classList.add('fast-scroll');
            }

            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                this.progress.classList.remove('fast-scroll');
            }, 150);
        }, { passive: true });
    }

    updateProgress(progress) {
        this.progress.style.setProperty('--scroll-width', `${progress}%`);
    }

    startColorAnimation() {
        setInterval(() => {
            this.currentColorIndex = (this.currentColorIndex + 1) % this.colors.length;
            const currentColor = this.colors[this.currentColorIndex];

            this.progress.style.setProperty('--ball-color-1', currentColor.ball[0]);
            this.progress.style.setProperty('--ball-color-2', currentColor.ball[1]);
            this.progress.style.setProperty('--trail-color-1', currentColor.trail[0]);
            this.progress.style.setProperty('--trail-color-2', currentColor.trail[1]);
        }, 5000);
    }

    destroy() {
        // Очистка ресурсов
    }
} 