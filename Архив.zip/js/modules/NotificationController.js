export class NotificationController {
    constructor(app) {
        this.app = app;
        this.container = null;
        this.notifications = new Map();
        this.queue = [];
        this.isProcessing = false;
        this.config = {
            maxVisible: 3,
            duration: 5000,
            position: 'top-right',
            animations: {
                enter: 'slide-in',
                exit: 'fade-out'
            }
        };

        this.init();
    }

    init() {
        this.createContainer();
        this.bindEvents();
    }

    createContainer() {
        this.container = document.createElement('div');
        this.container.className = 'notifications-container';
        this.container.setAttribute('role', 'alert');
        this.container.setAttribute('aria-live', 'polite');
        this.updatePosition(this.config.position);
        document.body.appendChild(this.container);
    }

    updatePosition(position) {
        this.container.className = `notifications-container notifications-${position}`;
    }

    bindEvents() {
        // Подписываемся на системные события
        this.app.events.on('form:success', ({ formId }) => {
            this.success(this.app.i18n.translate('notifications.form.success'));
        });

        this.app.events.on('form:error', ({ error }) => {
            this.error(this.app.i18n.translate('notifications.form.error'));
        });

        // Обработка изменения темы
        this.app.events.on('theme:changed', (theme) => {
            this.container.setAttribute('data-theme', theme);
        });

        // Обработка изменения размера окна
        window.addEventListener('resize', this.app.utils.debounce(() => {
            this.updateLayout();
        }, 150));
    }

    create(options) {
        const id = Math.random().toString(36).substr(2, 9);
        const notification = {
            id,
            type: options.type || 'info',
            message: options.message,
            duration: options.duration || this.config.duration,
            icon: this.getIcon(options.type),
            element: null
        };

        if (this.notifications.size >= this.config.maxVisible) {
            this.queue.push(notification);
        } else {
            this.show(notification);
        }

        return id;
    }

    getIcon(type) {
        const icons = {
            success: `
                <svg viewBox="0 0 24 24" width="24" height="24">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                </svg>
            `,
            error: `
                <svg viewBox="0 0 24 24" width="24" height="24">
                    <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/>
                </svg>
            `,
            info: `
                <svg viewBox="0 0 24 24" width="24" height="24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
                </svg>
            `,
            warning: `
                <svg viewBox="0 0 24 24" width="24" height="24">
                    <path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>
                </svg>
            `
        };

        return icons[type] || icons.info;
    }

    show(notification) {
        const element = document.createElement('div');
        element.className = `notification notification-${notification.type}`;
        element.innerHTML = `
            <div class="notification-icon">${notification.icon}</div>
            <div class="notification-content">${notification.message}</div>
            <button class="notification-close" aria-label="Close">
                <svg viewBox="0 0 24 24" width="24" height="24">
                    <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/>
                </svg>
            </button>
        `;

        // Добавляем обработчики
        element.querySelector('.notification-close').addEventListener('click', () => {
            this.dismiss(notification.id);
        });

        notification.element = element;
        this.notifications.set(notification.id, notification);
        this.container.appendChild(element);

        // Запускаем анимацию появления
        requestAnimationFrame(() => {
            element.classList.add(this.config.animations.enter);
        });

        // Устанавливаем таймер автоматического скрытия
        if (notification.duration > 0) {
            setTimeout(() => {
                this.dismiss(notification.id);
            }, notification.duration);
        }

        this.updateLayout();
    }

    async dismiss(id) {
        const notification = this.notifications.get(id);
        if (!notification) return;

        const element = notification.element;
        element.classList.add(this.config.animations.exit);

        // Ждем окончания анимации
        await new Promise(resolve => {
            element.addEventListener('animationend', resolve, { once: true });
        });

        element.remove();
        this.notifications.delete(id);

        // Показываем следующее уведомление из очереди
        if (this.queue.length > 0 && !this.isProcessing) {
            this.processQueue();
        }

        this.updateLayout();
    }

    async processQueue() {
        if (this.isProcessing || this.queue.length === 0) return;

        this.isProcessing = true;
        while (this.queue.length > 0 && this.notifications.size < this.config.maxVisible) {
            const notification = this.queue.shift();
            await this.show(notification);
        }
        this.isProcessing = false;
    }

    updateLayout() {
        const notifications = Array.from(this.container.children);
        let offset = 0;

        notifications.forEach((element, index) => {
            element.style.transform = `translateY(${offset}px)`;
            offset += element.offsetHeight + 10;
        });
    }

    // Вспомогательные методы для разных типов уведомлений
    success(message, options = {}) {
        return this.create({ ...options, type: 'success', message });
    }

    error(message, options = {}) {
        return this.create({ ...options, type: 'error', message });
    }

    info(message, options = {}) {
        return this.create({ ...options, type: 'info', message });
    }

    warning(message, options = {}) {
        return this.create({ ...options, type: 'warning', message });
    }

    destroy() {
        this.notifications.forEach((notification) => {
            notification.element.remove();
        });
        this.container.remove();
        window.removeEventListener('resize');
    }
} 