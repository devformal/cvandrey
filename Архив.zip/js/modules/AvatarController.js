export class AvatarController {
    constructor(app) {
        this.app = app;
        this.avatar = app.domElements.avatar;
        this.container = this.avatar.parentElement;
        this.isAnimating = false;
        this.scrollPosition = 0;

        this.init();
    }

    init() {
        // Параметры анимации
        this.config = {
            rotation: {
                max: 15,
                coefficient: 0.02
            },
            movement: {
                max: 20,
                coefficient: 0.05
            },
            scale: {
                base: 1,
                hover: 1.05,
                scroll: 0.001
            }
        };

        this.bindEvents();
        this.startParallaxEffect();
    }

    bindEvents() {
        // Интерактивность при наведении
        this.container.addEventListener('mousemove', this.handleMouseMove.bind(this));
        this.container.addEventListener('mouseleave', this.handleMouseLeave.bind(this));
        
        // Эффект при скролле
        this.app.events.on('scroll', this.handleScroll.bind(this));
    }

    handleMouseMove(e) {
        if (this.isAnimating) return;

        const rect = this.container.getBoundingClientRect();
        const x = (e.clientX - rect.left - rect.width / 2) / (rect.width / 2);
        const y = (e.clientY - rect.top - rect.height / 2) / (rect.height / 2);

        this.animateAvatar({
            rotateX: -y * this.config.rotation.max,
            rotateY: x * this.config.rotation.max,
            scale: this.config.scale.hover
        });
    }

    handleMouseLeave() {
        this.animateAvatar({
            rotateX: 0,
            rotateY: 0,
            scale: this.config.scale.base
        });
    }

    handleScroll(scrollData) {
        const { scrollDelta } = scrollData;
        
        if (Math.abs(scrollDelta) > 5) {
            const rotateX = Math.min(
                Math.max(-this.config.rotation.max, 
                scrollDelta * this.config.rotation.coefficient),
                this.config.rotation.max
            );

            this.animateAvatar({
                rotateX,
                scale: this.config.scale.base + Math.abs(scrollDelta) * this.config.scale.scroll
            });
        }
    }

    animateAvatar({ rotateX = 0, rotateY = 0, scale = 1 }) {
        this.avatar.style.transform = `
            rotateX(${rotateX}deg)
            rotateY(${rotateY}deg)
            scale(${scale})
        `;
    }

    startParallaxEffect() {
        let prevScrollY = window.scrollY;
        
        const animate = () => {
            const currentScrollY = window.scrollY;
            const scrollDelta = currentScrollY - prevScrollY;
            prevScrollY = currentScrollY;

            if (Math.abs(scrollDelta) > 0) {
                this.app.events.emit('scroll', { scrollDelta });
            }

            requestAnimationFrame(animate);
        };

        animate();
    }

    destroy() {
        this.container.removeEventListener('mousemove', this.handleMouseMove);
        this.container.removeEventListener('mouseleave', this.handleMouseLeave);
    }
} 