export class AnalyticsController {
    constructor(app) {
        this.app = app;
        this.metrics = new Map();
        this.events = new Map();
        this.isEnabled = this.app.config.get('analytics.enabled');
        this.queue = [];
        this.isProcessing = false;
        this.sessionId = this.generateSessionId();
        this.performanceMarks = new Map();

        this.init();
    }

    init() {
        if (!this.isEnabled) return;

        this.setupMetrics();
        this.bindEvents();
        this.startTracking();
        this.processQueue();
    }

    setupMetrics() {
        // Основные метрики
        this.addMetric('pageLoad', () => {
            const timing = performance.timing;
            return {
                total: timing.loadEventEnd - timing.navigationStart,
                network: timing.responseEnd - timing.fetchStart,
                dom: timing.domComplete - timing.domLoading,
                render: timing.domContentLoadedEventEnd - timing.domLoading
            };
        });

        // Метрики производительности
        this.addMetric('fps', () => {
            return {
                current: this.app.performance.getCurrentFPS(),
                average: this.app.performance.getAverageFPS(),
                drops: this.app.performance.getFrameDrops()
            };
        });

        // Метрики взаимодействия
        this.addMetric('interaction', () => {
            return {
                clicks: this.events.get('click') || 0,
                scrolls: this.events.get('scroll') || 0,
                forms: this.events.get('form') || 0
            };
        });

        // Метрики ресурсов
        this.addMetric('resources', () => {
            const resources = performance.getEntriesByType('resource');
            return {
                total: resources.length,
                size: resources.reduce((sum, r) => sum + r.encodedBodySize, 0),
                types: this.groupResourcesByType(resources)
            };
        });
    }

    bindEvents() {
        // Отслеживание взаимодействий
        document.addEventListener('click', () => this.incrementEvent('click'));
        window.addEventListener('scroll', () => this.incrementEvent('scroll'));
        
        // Отслеживание форм
        this.app.events.on('form:submit', () => this.incrementEvent('form'));

        // Отслеживание ошибок
        window.addEventListener('error', (e) => {
            this.trackError({
                type: 'error',
                message: e.message,
                stack: e.error?.stack,
                source: e.filename,
                line: e.lineno,
                column: e.colno
            });
        });

        // Отслеживание состояния сети
        window.addEventListener('online', () => this.trackEvent('network.online'));
        window.addEventListener('offline', () => this.trackEvent('network.offline'));

        // Отслеживание производительности
        this.app.events.on('performance:warning', (data) => {
            this.trackEvent('performance.warning', data);
        });

        // Отслеживание навигации
        this.app.events.on('route:changed', (data) => {
            this.trackPageView(data.path);
        });
    }

    startTracking() {
        // Начальные метки времени
        this.mark('appStart');

        // Отслеживание загрузки страницы
        window.addEventListener('load', () => {
            this.mark('appLoaded');
            this.trackPageLoad();
        });

        // Периодический сбор метрик
        setInterval(() => {
            this.collectMetrics();
        }, this.app.config.get('analytics.collectionInterval') || 30000);
    }

    addMetric(name, collector) {
        this.metrics.set(name, collector);
    }

    incrementEvent(name) {
        this.events.set(name, (this.events.get(name) || 0) + 1);
    }

    mark(name) {
        const time = performance.now();
        this.performanceMarks.set(name, time);
        performance.mark(name);
    }

    measure(start, end) {
        const startTime = this.performanceMarks.get(start);
        const endTime = this.performanceMarks.get(end);
        return endTime - startTime;
    }

    async collectMetrics() {
        const metrics = {};
        for (const [name, collector] of this.metrics) {
            try {
                metrics[name] = await collector();
            } catch (error) {
                this.app.logger.error(`Error collecting metric ${name}:`, error);
            }
        }

        this.queue.push({
            type: 'metrics',
            timestamp: Date.now(),
            sessionId: this.sessionId,
            data: metrics
        });
    }

    trackEvent(category, action, label = null, value = null) {
        this.queue.push({
            type: 'event',
            timestamp: Date.now(),
            sessionId: this.sessionId,
            data: { category, action, label, value }
        });
    }

    trackError(error) {
        this.queue.push({
            type: 'error',
            timestamp: Date.now(),
            sessionId: this.sessionId,
            data: error
        });
    }

    trackPageView(path) {
        this.queue.push({
            type: 'pageview',
            timestamp: Date.now(),
            sessionId: this.sessionId,
            data: { path }
        });
    }

    trackPageLoad() {
        const timing = performance.timing;
        const metrics = {
            total: timing.loadEventEnd - timing.navigationStart,
            ttfb: timing.responseStart - timing.navigationStart,
            domReady: timing.domContentLoadedEventEnd - timing.navigationStart,
            resources: timing.loadEventEnd - timing.domContentLoadedEventEnd,
            appReady: this.measure('appStart', 'appLoaded')
        };

        this.queue.push({
            type: 'pageload',
            timestamp: Date.now(),
            sessionId: this.sessionId,
            data: metrics
        });
    }

    async processQueue() {
        if (!this.isEnabled || this.isProcessing || this.queue.length === 0) return;

        this.isProcessing = true;
        const batch = this.queue.splice(0, 10);

        try {
            await fetch(this.app.config.get('analytics.endpoint'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    batch,
                    app: this.app.config.get('app.version'),
                    user: this.app.store.state.user?.id
                })
            });
        } catch (error) {
            this.app.logger.error('Failed to send analytics:', error);
            this.queue.unshift(...batch);
        }

        this.isProcessing = false;
        if (this.queue.length > 0) {
            setTimeout(() => this.processQueue(), 1000);
        }
    }

    groupResourcesByType(resources) {
        return resources.reduce((groups, resource) => {
            const type = resource.initiatorType;
            groups[type] = (groups[type] || 0) + 1;
            return groups;
        }, {});
    }

    generateSessionId() {
        return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    }

    destroy() {
        if (!this.isEnabled) return;

        // Отправляем оставшиеся данные
        if (this.queue.length > 0) {
            this.processQueue();
        }

        // Очищаем обработчики событий
        document.removeEventListener('click');
        window.removeEventListener('scroll');
        window.removeEventListener('error');
        window.removeEventListener('online');
        window.removeEventListener('offline');
    }
} 