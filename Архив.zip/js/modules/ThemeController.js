export class ThemeController {
    constructor(app) {
        this.app = app;
        this.themeToggle = app.domElements.themeToggle;
        this.prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
        this.currentTheme = localStorage.getItem('theme') || 'system';
        
        this.init();
    }

    init() {
        this.setupInitialTheme();
        this.bindEvents();
    }

    setupInitialTheme() {
        // Устанавливаем начальное состояние переключателя
        this.themeToggle.setAttribute('aria-checked', 
            this.currentTheme === 'dark' || 
            (this.currentTheme === 'system' && this.prefersDark.matches)
        );

        // Применяем тему
        this.applyTheme(this.currentTheme);
    }

    bindEvents() {
        // Обработка клика по переключателю
        this.themeToggle.addEventListener('click', () => {
            const nextTheme = this.getNextTheme();
            this.applyTheme(nextTheme);
            this.app.state.state.theme = nextTheme;
        });

        // Отслеживаем системные изменения темы
        this.prefersDark.addEventListener('change', (e) => {
            if (this.currentTheme === 'system') {
                this.applyTheme('system');
            }
        });

        // Подписываемся на изменения в state
        this.app.state.subscribe('theme', (newTheme) => {
            this.currentTheme = newTheme;
            this.applyTheme(newTheme);
        });
    }

    getNextTheme() {
        const themes = ['light', 'dark', 'system'];
        const currentIndex = themes.indexOf(this.currentTheme);
        return themes[(currentIndex + 1) % themes.length];
    }

    applyTheme(theme) {
        const root = document.documentElement;
        const isDark = theme === 'dark' || 
                      (theme === 'system' && this.prefersDark.matches);

        // Применяем тему
        root.setAttribute('data-theme', isDark ? 'dark' : 'light');
        
        // Обновляем состояние переключателя
        this.themeToggle.setAttribute('aria-checked', isDark);

        // Сохраняем выбор пользователя
        localStorage.setItem('theme', theme);

        // Обновляем мета-тег theme-color
        document.querySelector('meta[name="theme-color"]')
            .setAttribute('content', isDark ? '#0f172a' : '#ffffff');

        // Эмитим событие для других компонентов
        this.app.events.emit('theme:changed', {
            theme,
            isDark
        });
    }

    destroy() {
        this.prefersDark.removeEventListener('change');
        this.themeToggle.removeEventListener('click');
    }
} 