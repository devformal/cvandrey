// Выносим всю логику анимаций в отдельный модуль
export class AnimationController {
    constructor() {
        this.animations = new Map();
        this.frameId = null;
        this.isRunning = false;
    }

    add(name, callback) {
        this.animations.set(name, {
            callback,
            active: true
        });
    }

    remove(name) {
        this.animations.delete(name);
    }

    start() {
        if (this.isRunning) return;
        this.isRunning = true;
        this.animate();
    }

    stop() {
        this.isRunning = false;
        if (this.frameId) {
            cancelAnimationFrame(this.frameId);
        }
    }

    animate() {
        if (!this.isRunning) return;
        
        this.animations.forEach(({callback, active}, name) => {
            if (active) callback();
        });

        this.frameId = requestAnimationFrame(() => this.animate());
    }
} 