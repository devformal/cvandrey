export class RouterController {
    constructor(app) {
        this.app = app;
        this.routes = new Map();
        this.currentRoute = null;
        this.history = [];
        this.maxHistoryLength = 50;

        this.init();
    }

    init() {
        this.setupRoutes();
        this.bindEvents();
        this.handleInitialRoute();
    }

    setupRoutes() {
        // Определяем маршруты и их обработчики
        this.addRoute('/', {
            title: 'Home',
            handler: () => this.showSection('profile')
        });

        this.addRoute('/research', {
            title: 'Research',
            handler: () => this.showSection('research')
        });

        this.addRoute('/publications', {
            title: 'Publications',
            handler: () => this.showSection('publications')
        });

        // Обработчик для несуществующих маршрутов
        this.addRoute('404', {
            title: 'Page Not Found',
            handler: () => this.showError('404')
        });
    }

    addRoute(path, config) {
        this.routes.set(path, {
            ...config,
            path,
            regex: this.pathToRegex(path)
        });
    }

    pathToRegex(path) {
        return new RegExp('^' + path.replace(/\//g, '\\/').replace(/:\w+/g, '(.+)') + '$');
    }

    bindEvents() {
        // Обработка клика по внутренним ссылкам
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a');
            if (link && link.href.startsWith(window.location.origin)) {
                e.preventDefault();
                const path = link.pathname;
                this.navigate(path);
            }
        });

        // Обработка навигации браузера
        window.addEventListener('popstate', (e) => {
            this.handleRoute(window.location.pathname, false);
        });

        // Подписываемся на изменение языка
        this.app.state.subscribe('locale', (newLocale) => {
            this.updateUrlLocale(newLocale);
        });
    }

    async handleRoute(path, pushState = true) {
        let route = null;
        let params = {};

        // Ищем подходящий маршрут
        for (const [_, routeConfig] of this.routes) {
            const match = path.match(routeConfig.regex);
            if (match) {
                route = routeConfig;
                params = match.slice(1);
                break;
            }
        }

        // Если маршрут не найден, показываем 404
        if (!route) {
            route = this.routes.get('404');
        }

        // Сохраняем текущий маршрут в историю
        if (pushState) {
            this.addToHistory(path);
            window.history.pushState(null, '', path);
        }

        // Обновляем заголовок страницы
        const title = await this.getLocalizedTitle(route.title);
        document.title = `${title} | ${this.app.config.siteName}`;

        // Вызываем обработчик маршрута
        this.currentRoute = route;
        await route.handler(params);

        // Эмитим событие смены маршрута
        this.app.events.emit('route:changed', {
            path,
            route,
            params
        });
    }

    async getLocalizedTitle(key) {
        return this.app.i18n.translate(`routes.${key}`);
    }

    showSection(sectionId) {
        // Скрываем все секции
        document.querySelectorAll('section[data-route]').forEach(section => {
            section.style.display = 'none';
        });

        // Показываем нужную секцию
        const section = document.querySelector(`section[data-route="${sectionId}"]`);
        if (section) {
            section.style.display = 'block';
            // Запускаем анимации для секции
            this.app.animations.playAnimation(section, 'fadeIn');
        }
    }

    showError(code) {
        // Показываем страницу ошибки
        const errorSection = document.querySelector('.error-section');
        if (errorSection) {
            errorSection.style.display = 'block';
            errorSection.querySelector('.error-code').textContent = code;
        }
    }

    navigate(path, options = {}) {
        const { replace = false, scroll = true } = options;

        if (replace) {
            window.history.replaceState(null, '', path);
        }

        this.handleRoute(path);

        if (scroll) {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
    }

    addToHistory(path) {
        this.history.push({
            path,
            timestamp: Date.now()
        });

        // Ограничиваем размер истории
        if (this.history.length > this.maxHistoryLength) {
            this.history.shift();
        }
    }

    handleInitialRoute() {
        const path = window.location.pathname;
        this.handleRoute(path, false);
    }

    updateUrlLocale(locale) {
        if (this.currentRoute) {
            const path = this.currentRoute.path;
            const localizedPath = `/${locale}${path}`;
            window.history.replaceState(null, '', localizedPath);
        }
    }

    destroy() {
        // Очистка обработчиков событий
    }
} 