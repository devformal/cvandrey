export class I18nController {
    constructor(app) {
        this.app = app;
        this.currentLocale = localStorage.getItem('locale') || navigator.language.split('-')[0] || 'en';
        this.translations = new Map();
        this.fallbackLocale = 'en';
        
        this.init();
    }

    init() {
        // Загружаем переводы для текущей локали
        this.loadTranslations(this.currentLocale)
            .then(() => {
                this.applyTranslations();
                this.bindEvents();
            })
            .catch(error => {
                this.app.logger.log(Logger.levels.ERROR, 'Failed to load translations:', error);
            });
    }

    async loadTranslations(locale) {
        try {
            const response = await fetch(`/locales/${locale}.json`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const translations = await response.json();
            this.translations.set(locale, translations);
        } catch (error) {
            // Если не удалось загрузить переводы, используем fallback
            if (locale !== this.fallbackLocale) {
                await this.loadTranslations(this.fallbackLocale);
            }
            throw error;
        }
    }

    bindEvents() {
        // Подписываемся на изменения языка в state
        this.app.state.subscribe('locale', async (newLocale) => {
            if (!this.translations.has(newLocale)) {
                await this.loadTranslations(newLocale);
            }
            this.currentLocale = newLocale;
            this.applyTranslations();
            document.documentElement.setAttribute('lang', newLocale);
            localStorage.setItem('locale', newLocale);
        });

        // Добавляем обработчики для переключения языка
        document.querySelectorAll('[data-language]').forEach(button => {
            button.addEventListener('click', () => {
                const locale = button.dataset.language;
                this.app.state.state.locale = locale;
            });
        });
    }

    applyTranslations() {
        const translations = this.translations.get(this.currentLocale) || 
                           this.translations.get(this.fallbackLocale);

        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.dataset.i18n;
            const translation = this.getNestedTranslation(translations, key);
            
            if (translation) {
                // Проверяем, есть ли HTML в переводе
                if (/<[^>]*>/g.test(translation)) {
                    element.innerHTML = translation;
                } else {
                    element.textContent = translation;
                }
            }
        });

        // Обновляем мета-теги
        this.updateMetaTags(translations.meta || {});
    }

    getNestedTranslation(translations, key) {
        return key.split('.').reduce((obj, k) => obj && obj[k], translations) || key;
    }

    updateMetaTags(meta) {
        // Обновляем title
        document.title = meta.title || document.title;

        // Обновляем мета-описание
        const descriptionTag = document.querySelector('meta[name="description"]');
        if (descriptionTag && meta.description) {
            descriptionTag.setAttribute('content', meta.description);
        }

        // Обновляем Open Graph теги
        const ogTitleTag = document.querySelector('meta[property="og:title"]');
        const ogDescTag = document.querySelector('meta[property="og:description"]');
        
        if (ogTitleTag && meta.ogTitle) {
            ogTitleTag.setAttribute('content', meta.ogTitle);
        }
        if (ogDescTag && meta.ogDescription) {
            ogDescTag.setAttribute('content', meta.ogDescription);
        }
    }

    // Вспомогательный метод для получения перевода программно
    translate(key, params = {}) {
        const translations = this.translations.get(this.currentLocale) || 
                           this.translations.get(this.fallbackLocale);
        let translation = this.getNestedTranslation(translations, key);

        // Подставляем параметры в перевод
        Object.entries(params).forEach(([key, value]) => {
            translation = translation.replace(`{${key}}`, value);
        });

        return translation;
    }

    destroy() {
        document.querySelectorAll('[data-language]').forEach(button => {
            button.removeEventListener('click');
        });
    }
} 