export class ProjectsController {
    constructor(app) {
        this.app = app;
        this.projects = new Map();
        this.activeProject = null;
        this.filters = {
            status: 'all',
            category: 'all'
        };

        this.init();
    }

    init() {
        this.loadProjects();
        this.setupFilters();
        this.bindEvents();
    }

    async loadProjects() {
        try {
            const response = await fetch('/data/projects.json');
            const data = await response.json();
            
            data.forEach(project => {
                this.projects.set(project.id, {
                    ...project,
                    element: this.createProjectElement(project)
                });
            });

            this.renderProjects();
            this.initializeVisualizations();

        } catch (error) {
            this.app.logger.error('Failed to load projects:', error);
        }
    }

    createProjectElement(project) {
        const template = `
            <article class="project" data-id="${project.id}">
                <div class="project-header">
                    <h3 class="project-title">${project.title}</h3>
                    <span class="project-status ${project.status}">${project.status}</span>
                </div>
                
                <div class="project-preview">
                    ${project.image ? `
                        <img src="${project.image}" alt="${project.title}" loading="lazy">
                    ` : ''}
                    ${project.video ? `
                        <div class="video-preview" data-video="${project.video}">
                            <button class="play-button">Play Demo</button>
                        </div>
                    ` : ''}
                </div>

                <div class="project-content">
                    <p class="project-description">${project.description}</p>
                    
                    ${project.experiments ? `
                        <div class="experiments-section">
                            <h4>Experiments</h4>
                            <div class="experiments-list">
                                ${project.experiments.map(exp => `
                                    <div class="experiment">
                                        <h5>${exp.title}</h5>
                                        <p>${exp.description}</p>
                                        ${exp.results ? `
                                            <div class="experiment-results" data-chart="${exp.id}">
                                                <canvas></canvas>
                                            </div>
                                        ` : ''}
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}

                    ${project.tools ? `
                        <div class="tools-used">
                            <h4>Tools & Technologies</h4>
                            <div class="tools-list">
                                ${project.tools.map(tool => `
                                    <span class="tool-tag">${tool}</span>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}

                    <div class="project-links">
                        ${project.github ? `
                            <a href="${project.github}" target="_blank" class="github-link">
                                <svg>...</svg> View on GitHub
                            </a>
                        ` : ''}
                        ${project.demo ? `
                            <a href="${project.demo}" target="_blank" class="demo-link">
                                Live Demo
                            </a>
                        ` : ''}
                        ${project.paper ? `
                            <a href="${project.paper}" target="_blank" class="paper-link">
                                Read Paper
                            </a>
                        ` : ''}
                    </div>
                </div>
            </article>
        `;

        const element = document.createElement('div');
        element.innerHTML = template.trim();
        return element.firstElementChild;
    }

    setupFilters() {
        const container = document.querySelector('.projects-filters');
        if (!container) return;

        const statuses = new Set([...this.projects.values()].map(p => p.status));
        const categories = new Set([...this.projects.values()].map(p => p.category));

        container.innerHTML = `
            <div class="filter-group">
                <label>Status</label>
                <select data-filter="status">
                    <option value="all">All statuses</option>
                    ${[...statuses].map(status => 
                        `<option value="${status}">${status}</option>`
                    ).join('')}
                </select>
            </div>
            <div class="filter-group">
                <label>Category</label>
                <select data-filter="category">
                    <option value="all">All categories</option>
                    ${[...categories].map(category => 
                        `<option value="${category}">${category}</option>`
                    ).join('')}
                </select>
            </div>
        `;
    }

    initializeVisualizations() {
        this.projects.forEach(project => {
            if (project.experiments) {
                project.experiments.forEach(exp => {
                    if (exp.results) {
                        const canvas = project.element.querySelector(`[data-chart="${exp.id}"] canvas`);
                        if (canvas) {
                            this.createChart(canvas, exp.results);
                        }
                    }
                });
            }
        });
    }

    createChart(canvas, data) {
        // Используем Chart.js или другую библиотеку для визуализации
        const ctx = canvas.getContext('2d');
        // ... настройка и отрисовка графика
    }

    bindEvents() {
        // Обработка фильтров
        document.querySelectorAll('[data-filter]').forEach(select => {
            select.addEventListener('change', (e) => {
                const filter = e.target.dataset.filter;
                this.filters[filter] = e.target.value;
                this.renderProjects();
            });
        });

        // Обработка видео
        document.addEventListener('click', (e) => {
            const playButton = e.target.closest('.play-button');
            if (playButton) {
                const videoContainer = playButton.closest('.video-preview');
                const videoUrl = videoContainer.dataset.video;
                this.playVideo(videoContainer, videoUrl);
            }
        });

        // Анимация при скролле
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.2 });

        document.querySelectorAll('.project').forEach(project => {
            observer.observe(project);
        });
    }

    playVideo(container, videoUrl) {
        container.innerHTML = `
            <iframe 
                src="${videoUrl}?autoplay=1" 
                frameborder="0" 
                allow="autoplay; encrypted-media" 
                allowfullscreen
            ></iframe>
        `;
    }

    renderProjects() {
        const container = document.querySelector('.projects-list');
        if (!container) return;

        container.innerHTML = '';
        
        const filtered = [...this.projects.values()].filter(project => {
            return (this.filters.status === 'all' || project.status === this.filters.status) &&
                   (this.filters.category === 'all' || project.category === this.filters.category);
        });

        filtered.forEach(project => {
            container.appendChild(project.element.cloneNode(true));
        });
    }

    destroy() {
        document.querySelectorAll('[data-filter]').forEach(select => {
            select.removeEventListener('change');
        });
    }
} 