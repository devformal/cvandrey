export class LoadingController {
    constructor(app) {
        this.app = app;
        this.progressBar = null;
        this.loadingScreen = null;
        this.progress = 0;
        this.isLoading = false;
        this.queue = new Set();
        this.completedTasks = new Set();

        this.init();
    }

    init() {
        this.createElements();
        this.bindEvents();
        this.startInitialLoading();
    }

    createElements() {
        // Создаем экран загрузки
        this.loadingScreen = document.createElement('div');
        this.loadingScreen.className = 'loading-screen';
        this.loadingScreen.innerHTML = `
            <div class="loading-content">
                <div class="loading-spinner"></div>
                <div class="loading-progress">
                    <div class="progress-bar">
                        <div class="progress-fill"></div>
                    </div>
                    <div class="progress-text">0%</div>
                </div>
                <div class="loading-message"></div>
            </div>
        `;

        this.progressBar = this.loadingScreen.querySelector('.progress-fill');
        document.body.appendChild(this.loadingScreen);
    }

    bindEvents() {
        // Отслеживаем загрузку ресурсов
        window.addEventListener('load', () => {
            this.completeTask('resources');
        });

        // Отслеживаем состояние сети
        window.addEventListener('online', () => {
            this.app.notifications.info(
                this.app.i18n.translate('notifications.network.online')
            );
        });

        window.addEventListener('offline', () => {
            this.app.notifications.warning(
                this.app.i18n.translate('notifications.network.offline')
            );
        });

        // Подписываемся на системные события
        this.app.events.on('loading:start', ({ task, message }) => {
            this.addTask(task, message);
        });

        this.app.events.on('loading:complete', ({ task }) => {
            this.completeTask(task);
        });

        this.app.events.on('loading:error', ({ task, error }) => {
            this.handleError(task, error);
        });
    }

    startInitialLoading() {
        // Добавляем начальные задачи
        this.addTask('resources', 'Loading resources...');
        this.addTask('initialization', 'Initializing application...');
        
        // Имитируем загрузку приложения
        setTimeout(() => {
            this.completeTask('initialization');
        }, 1000);
    }

    addTask(taskId, message = '') {
        if (this.completedTasks.has(taskId)) return;

        this.queue.add(taskId);
        this.updateProgress();
        this.showLoadingScreen(message);
    }

    completeTask(taskId) {
        if (!this.queue.has(taskId)) return;

        this.queue.delete(taskId);
        this.completedTasks.add(taskId);
        this.updateProgress();

        if (this.queue.size === 0) {
            this.hideLoadingScreen();
        }
    }

    updateProgress() {
        const total = this.completedTasks.size + this.queue.size;
        const completed = this.completedTasks.size;
        this.progress = total > 0 ? (completed / total) * 100 : 0;

        // Обновляем UI
        this.progressBar.style.width = `${this.progress}%`;
        this.loadingScreen.querySelector('.progress-text').textContent = 
            `${Math.round(this.progress)}%`;

        // Эмитим событие прогресса
        this.app.events.emit('loading:progress', {
            progress: this.progress,
            completed,
            total
        });
    }

    showLoadingScreen(message = '') {
        if (!this.isLoading) {
            this.isLoading = true;
            document.body.classList.add('is-loading');
            this.loadingScreen.classList.add('is-visible');
        }

        if (message) {
            this.loadingScreen.querySelector('.loading-message').textContent = message;
        }
    }

    async hideLoadingScreen() {
        if (!this.isLoading) return;

        // Добавляем небольшую задержку для плавности
        await new Promise(resolve => setTimeout(resolve, 500));

        this.loadingScreen.classList.add('is-hiding');
        
        // Ждем окончания анимации
        await new Promise(resolve => {
            this.loadingScreen.addEventListener('animationend', resolve, { once: true });
        });

        this.isLoading = false;
        document.body.classList.remove('is-loading');
        this.loadingScreen.classList.remove('is-visible', 'is-hiding');
    }

    handleError(taskId, error) {
        this.app.logger.error(`Loading error in task ${taskId}:`, error);
        this.app.notifications.error(
            this.app.i18n.translate('notifications.loading.error', { task: taskId })
        );

        // Удаляем задачу из очереди
        this.queue.delete(taskId);
        this.updateProgress();

        if (this.queue.size === 0) {
            this.hideLoadingScreen();
        }
    }

    // Публичные методы для управления загрузкой
    startLoading(taskId, message) {
        this.addTask(taskId, message);
        return {
            complete: () => this.completeTask(taskId),
            error: (error) => this.handleError(taskId, error)
        };
    }

    setMessage(message) {
        if (this.isLoading) {
            this.loadingScreen.querySelector('.loading-message').textContent = message;
        }
    }

    reset() {
        this.queue.clear();
        this.completedTasks.clear();
        this.progress = 0;
        this.updateProgress();
    }

    destroy() {
        this.loadingScreen.remove();
        window.removeEventListener('load');
        window.removeEventListener('online');
        window.removeEventListener('offline');
    }
} 