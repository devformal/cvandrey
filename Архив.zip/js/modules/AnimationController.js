export class AnimationController {
    constructor(app) {
        this.app = app;
        this.animations = new Map();
        this.intersectionObserver = null;
        this.rafId = null;
        this.isRunning = false;

        this.init();
    }

    init() {
        this.setupIntersectionObserver();
        this.setupParallaxEffects();
        this.setupScrollAnimations();
        this.bindEvents();
    }

    setupIntersectionObserver() {
        this.intersectionObserver = new IntersectionObserver(
            (entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const element = entry.target;
                        const animation = element.dataset.animation;
                        if (animation) {
                            this.playAnimation(element, animation);
                        }
                        // Прекращаем наблюдение после первой анимации
                        this.intersectionObserver.unobserve(element);
                    }
                });
            },
            {
                threshold: 0.2,
                rootMargin: '50px'
            }
        );

        // Наблюдаем за всеми элементами с анимациями
        document.querySelectorAll('[data-animation]').forEach(element => {
            this.intersectionObserver.observe(element);
        });
    }

    setupParallaxEffects() {
        const parallaxElements = document.querySelectorAll('[data-parallax]');
        
        parallaxElements.forEach(element => {
            const speed = parseFloat(element.dataset.parallax) || 0.5;
            const initialY = element.getBoundingClientRect().top;
            
            this.animations.set(element, {
                type: 'parallax',
                speed,
                initialY,
                animate: (scrollY) => {
                    const offset = scrollY * speed;
                    element.style.transform = `translate3d(0, ${offset}px, 0)`;
                }
            });
        });
    }

    setupScrollAnimations() {
        const scrollElements = document.querySelectorAll('[data-scroll-animation]');
        
        scrollElements.forEach(element => {
            const type = element.dataset.scrollAnimation;
            const config = {
                fade: {
                    start: { opacity: 0, transform: 'translateY(20px)' },
                    end: { opacity: 1, transform: 'translateY(0)' }
                },
                scale: {
                    start: { opacity: 0, transform: 'scale(0.8)' },
                    end: { opacity: 1, transform: 'scale(1)' }
                },
                slideIn: {
                    start: { opacity: 0, transform: 'translateX(-50px)' },
                    end: { opacity: 1, transform: 'translateX(0)' }
                }
            }[type] || config.fade;

            element.style.opacity = '0';
            element.style.transition = 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
            
            this.animations.set(element, {
                type: 'scroll',
                config,
                animate: (progress) => {
                    Object.entries(config.start).forEach(([property, startValue]) => {
                        const endValue = config.end[property];
                        const currentValue = this.interpolate(startValue, endValue, progress);
                        element.style[property] = currentValue;
                    });
                }
            });
        });
    }

    interpolate(start, end, progress) {
        if (typeof start === 'number') {
            return start + (end - start) * progress;
        }
        // Для transform и других CSS-свойств
        return start.replace(/[-\d.]+/g, (match) => {
            const startNum = parseFloat(match);
            const endNum = parseFloat(end.match(/[-\d.]+/g)[0]);
            return startNum + (endNum - startNum) * progress;
        });
    }

    playAnimation(element, animationType) {
        const animations = {
            fadeIn: [
                { opacity: 0, transform: 'translateY(20px)' },
                { opacity: 1, transform: 'translateY(0)' }
            ],
            scaleIn: [
                { opacity: 0, transform: 'scale(0.8)' },
                { opacity: 1, transform: 'scale(1)' }
            ],
            slideIn: [
                { opacity: 0, transform: 'translateX(-50px)' },
                { opacity: 1, transform: 'translateX(0)' }
            ]
        };

        const options = {
            duration: 600,
            easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
            fill: 'forwards'
        };

        element.animate(animations[animationType] || animations.fadeIn, options);
    }

    bindEvents() {
        window.addEventListener('scroll', () => {
            if (!this.isRunning) {
                this.isRunning = true;
                this.rafId = requestAnimationFrame(() => this.update());
            }
        }, { passive: true });

        // Обработка изменений размера окна
        window.addEventListener('resize', this.app.utils.debounce(() => {
            this.setupParallaxEffects();
        }, 150));
    }

    update() {
        const scrollY = window.scrollY;
        const viewportHeight = window.innerHeight;

        this.animations.forEach((animation, element) => {
            const rect = element.getBoundingClientRect();
            const progress = Math.max(0, Math.min(1, 
                1 - (rect.top - viewportHeight * 0.5) / (viewportHeight * 0.5)
            ));

            animation.animate(scrollY, progress);
        });

        this.isRunning = false;
    }

    destroy() {
        if (this.rafId) {
            cancelAnimationFrame(this.rafId);
        }
        if (this.intersectionObserver) {
            this.intersectionObserver.disconnect();
        }
        window.removeEventListener('scroll');
        window.removeEventListener('resize');
    }
} 