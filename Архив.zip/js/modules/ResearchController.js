export class ResearchController {
    constructor(app) {
        this.app = app;
        this.publications = new Map();
        this.researchAreas = new Map();
        this.filters = {
            year: 'all',
            type: 'all',
            area: 'all'
        };

        this.init();
    }

    init() {
        this.loadPublications();
        this.setupFilters();
        this.bindEvents();
    }

    async loadPublications() {
        try {
            const response = await fetch('/data/publications.json');
            const data = await response.json();
            
            data.forEach(pub => {
                this.publications.set(pub.id, {
                    ...pub,
                    element: this.createPublicationElement(pub)
                });
                
                // Собираем области исследований
                pub.areas.forEach(area => {
                    if (!this.researchAreas.has(area)) {
                        this.researchAreas.set(area, {
                            count: 0,
                            publications: new Set()
                        });
                    }
                    const areaData = this.researchAreas.get(area);
                    areaData.count++;
                    areaData.publications.add(pub.id);
                });
            });

            this.renderPublications();
            this.renderResearchAreas();

        } catch (error) {
            this.app.logger.error('Failed to load publications:', error);
        }
    }

    createPublicationElement(pub) {
        const template = `
            <article class="publication" data-id="${pub.id}">
                <div class="publication-meta">
                    <span class="publication-year">${pub.year}</span>
                    <span class="publication-type">${pub.type}</span>
                </div>
                <h3 class="publication-title">${pub.title}</h3>
                <p class="publication-authors">${pub.authors.join(', ')}</p>
                <p class="publication-venue">${pub.venue}</p>
                <div class="publication-links">
                    ${pub.doi ? `<a href="https://doi.org/${pub.doi}" target="_blank">DOI</a>` : ''}
                    ${pub.pdf ? `<a href="${pub.pdf}" target="_blank">PDF</a>` : ''}
                    ${pub.code ? `<a href="${pub.code}" target="_blank">Code</a>` : ''}
                </div>
                <div class="publication-areas">
                    ${pub.areas.map(area => `
                        <span class="area-tag" data-area="${area}">${area}</span>
                    `).join('')}
                </div>
                ${pub.abstract ? `
                    <div class="publication-abstract">
                        <button class="abstract-toggle">Abstract</button>
                        <div class="abstract-content hidden">${pub.abstract}</div>
                    </div>
                ` : ''}
            </article>
        `;

        const element = document.createElement('div');
        element.innerHTML = template.trim();
        return element.firstElementChild;
    }

    setupFilters() {
        const container = document.querySelector('.publications-filters');
        if (!container) return;

        // Создаем фильтры
        const years = new Set([...this.publications.values()].map(p => p.year));
        const types = new Set([...this.publications.values()].map(p => p.type));

        container.innerHTML = `
            <div class="filter-group">
                <label>Year</label>
                <select data-filter="year">
                    <option value="all">All years</option>
                    ${[...years].sort().reverse().map(year => 
                        `<option value="${year}">${year}</option>`
                    ).join('')}
                </select>
            </div>
            <div class="filter-group">
                <label>Type</label>
                <select data-filter="type">
                    <option value="all">All types</option>
                    ${[...types].map(type => 
                        `<option value="${type}">${type}</option>`
                    ).join('')}
                </select>
            </div>
            <div class="filter-group">
                <label>Research Area</label>
                <select data-filter="area">
                    <option value="all">All areas</option>
                    ${[...this.researchAreas.keys()].map(area => 
                        `<option value="${area}">${area}</option>`
                    ).join('')}
                </select>
            </div>
        `;
    }

    bindEvents() {
        // Обработка фильтров
        document.querySelectorAll('[data-filter]').forEach(select => {
            select.addEventListener('change', (e) => {
                const filter = e.target.dataset.filter;
                this.filters[filter] = e.target.value;
                this.renderPublications();
            });
        });

        // Обработка клика по области исследований
        document.addEventListener('click', (e) => {
            const areaTag = e.target.closest('.area-tag');
            if (areaTag) {
                const area = areaTag.dataset.area;
                this.filters.area = area;
                document.querySelector('[data-filter="area"]').value = area;
                this.renderPublications();
            }
        });

        // Обработка переключения абстрактов
        document.addEventListener('click', (e) => {
            const toggle = e.target.closest('.abstract-toggle');
            if (toggle) {
                const content = toggle.nextElementSibling;
                content.classList.toggle('hidden');
                toggle.textContent = content.classList.contains('hidden') ? 'Abstract' : 'Hide';
            }
        });
    }

    renderPublications() {
        const container = document.querySelector('.publications-list');
        if (!container) return;

        container.innerHTML = '';
        
        // Фильтруем публикации
        const filtered = [...this.publications.values()].filter(pub => {
            return (this.filters.year === 'all' || pub.year === parseInt(this.filters.year)) &&
                   (this.filters.type === 'all' || pub.type === this.filters.type) &&
                   (this.filters.area === 'all' || pub.areas.includes(this.filters.area));
        });

        // Сортируем по году (новые сверху)
        filtered.sort((a, b) => b.year - a.year);

        // Добавляем на страницу
        filtered.forEach(pub => {
            container.appendChild(pub.element.cloneNode(true));
        });

        // Обновляем счетчик
        const count = document.querySelector('.publications-count');
        if (count) {
            count.textContent = `Showing ${filtered.length} publications`;
        }
    }

    renderResearchAreas() {
        const container = document.querySelector('.research-areas');
        if (!container) return;

        const template = [...this.researchAreas.entries()].map(([area, data]) => `
            <div class="research-area" data-area="${area}">
                <h3>${area}</h3>
                <span class="publication-count">${data.count} publications</span>
                <div class="area-preview">
                    ${[...data.publications].slice(0, 3).map(id => {
                        const pub = this.publications.get(id);
                        return `<div class="preview-publication">
                            <span class="preview-year">${pub.year}</span>
                            <span class="preview-title">${pub.title}</span>
                        </div>`;
                    }).join('')}
                </div>
            </div>
        `).join('');

        container.innerHTML = template;
    }

    destroy() {
        // Очистка обработчиков
        document.querySelectorAll('[data-filter]').forEach(select => {
            select.removeEventListener('change');
        });
    }
} 