export class HoverEffectsController {
    constructor(app) {
        this.app = app;
        this.effects = new Map();
        this.activeEffects = new Set();
        this.mousePosition = { x: 0, y: 0 };
        this.isRunning = false;
        this.rafId = null;

        this.init();
    }

    init() {
        this.setupEffects();
        this.bindEvents();
        this.startAnimation();
    }

    setupEffects() {
        // Эффект магнитного притяжения
        this.addEffect('magnetic', {
            selector: '[data-magnetic]',
            handler: (element, mouseInfo) => {
                const rect = element.getBoundingClientRect();
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                const distanceX = mouseInfo.x - centerX;
                const distanceY = mouseInfo.y - centerY;
                const distance = Math.sqrt(distanceX ** 2 + distanceY ** 2);
                const radius = parseFloat(element.dataset.magnetic) || 100;

                if (distance < radius) {
                    const power = (1 - distance / radius) * 30;
                    const moveX = distanceX * power / distance;
                    const moveY = distanceY * power / distance;
                    element.style.transform = `translate(${moveX}px, ${moveY}px)`;
                } else {
                    element.style.transform = '';
                }
            },
            reset: (element) => {
                element.style.transform = '';
                element.style.transition = 'transform 0.3s ease-out';
                requestAnimationFrame(() => {
                    element.style.transition = '';
                });
            }
        });

        // Эффект свечения
        this.addEffect('glow', {
            selector: '[data-glow]',
            handler: (element, mouseInfo) => {
                const rect = element.getBoundingClientRect();
                const x = mouseInfo.x - rect.left;
                const y = mouseInfo.y - rect.top;
                const intensity = parseFloat(element.dataset.glow) || 1;

                element.style.background = `
                    radial-gradient(
                        circle at ${x}px ${y}px,
                        rgba(255, 255, 255, ${0.2 * intensity}),
                        transparent 80px
                    )
                `;
            },
            reset: (element) => {
                element.style.background = '';
            }
        });

        // Эффект искажения текста
        this.addEffect('text-distort', {
            selector: '[data-text-distort]',
            setup: (element) => {
                if (!element.dataset.originalText) {
                    element.dataset.originalText = element.textContent;
                }
            },
            handler: (element, mouseInfo) => {
                const text = element.dataset.originalText;
                const intensity = parseFloat(element.dataset.textDistort) || 0.3;
                const distortedText = text.split('').map(char => {
                    if (Math.random() < intensity) {
                        return String.fromCharCode(char.charCodeAt(0) + Math.floor(Math.random() * 5) - 2);
                    }
                    return char;
                }).join('');
                element.textContent = distortedText;
            },
            reset: (element) => {
                element.textContent = element.dataset.originalText;
            }
        });

        // Эффект 3D поворота
        this.addEffect('tilt', {
            selector: '[data-tilt]',
            handler: (element, mouseInfo) => {
                const rect = element.getBoundingClientRect();
                const x = (mouseInfo.x - rect.left) / rect.width;
                const y = (mouseInfo.y - rect.top) / rect.height;
                const intensity = parseFloat(element.dataset.tilt) || 20;

                const rotateX = (0.5 - y) * intensity;
                const rotateY = (x - 0.5) * intensity;

                element.style.transform = `
                    perspective(1000px)
                    rotateX(${rotateX}deg)
                    rotateY(${rotateY}deg)
                    scale3d(1.05, 1.05, 1.05)
                `;
            },
            reset: (element) => {
                element.style.transform = '';
                element.style.transition = 'transform 0.3s ease-out';
                requestAnimationFrame(() => {
                    element.style.transition = '';
                });
            }
        });
    }

    addEffect(name, config) {
        this.effects.set(name, {
            elements: document.querySelectorAll(config.selector),
            ...config
        });

        // Инициализация элементов
        if (config.setup) {
            document.querySelectorAll(config.selector).forEach(config.setup);
        }
    }

    bindEvents() {
        document.addEventListener('mousemove', (e) => {
            this.mousePosition = { x: e.clientX, y: e.clientY };
            if (!this.isRunning) {
                this.isRunning = true;
                this.rafId = requestAnimationFrame(() => this.update());
            }
        });

        this.effects.forEach((effect, name) => {
            effect.elements.forEach(element => {
                element.addEventListener('mouseenter', () => {
                    this.activeEffects.add(name);
                });

                element.addEventListener('mouseleave', () => {
                    this.activeEffects.delete(name);
                    if (effect.reset) {
                        effect.reset(element);
                    }
                });
            });
        });
    }

    update() {
        this.activeEffects.forEach(effectName => {
            const effect = this.effects.get(effectName);
            effect.elements.forEach(element => {
                if (this.isElementInViewport(element)) {
                    effect.handler(element, this.mousePosition);
                }
            });
        });

        this.isRunning = false;
    }

    isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top < window.innerHeight &&
            rect.bottom > 0 &&
            rect.left < window.innerWidth &&
            rect.right > 0
        );
    }

    startAnimation() {
        const animate = () => {
            if (!document.hidden && this.activeEffects.size > 0) {
                this.update();
            }
            this.rafId = requestAnimationFrame(animate);
        };

        animate();
    }

    destroy() {
        if (this.rafId) {
            cancelAnimationFrame(this.rafId);
        }
        document.removeEventListener('mousemove');
        this.effects.forEach(effect => {
            effect.elements.forEach(element => {
                if (effect.reset) {
                    effect.reset(element);
                }
            });
        });
    }
} 