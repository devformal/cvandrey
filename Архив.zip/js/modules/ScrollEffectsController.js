export class ScrollEffectsController {
    constructor(app) {
        this.app = app;
        this.effects = new Map();
        this.isRunning = false;
        this.rafId = null;
        this.lastScrollY = window.scrollY;
        this.scrollDirection = 'down';
        this.scrollSpeed = 0;

        this.init();
    }

    init() {
        this.setupEffects();
        this.bindEvents();
        this.startAnimation();
    }

    setupEffects() {
        // Эффект параллакса для фоновых элементов
        this.addEffect('parallax', {
            selector: '[data-parallax]',
            handler: (element, scrollInfo) => {
                const speed = parseFloat(element.dataset.parallax) || 0.5;
                const offset = scrollInfo.y * speed;
                element.style.transform = `translate3d(0, ${offset}px, 0)`;
            }
        });

        // Эффект появления элементов
        this.addEffect('fade-in', {
            selector: '[data-fade-in]',
            handler: (element, scrollInfo) => {
                const rect = element.getBoundingClientRect();
                const viewportHeight = window.innerHeight;
                const entryPoint = viewportHeight * 0.8;

                if (rect.top < entryPoint) {
                    const progress = Math.min(1, (entryPoint - rect.top) / (viewportHeight * 0.2));
                    element.style.opacity = progress;
                    element.style.transform = `translateY(${20 * (1 - progress)}px)`;
                }
            }
        });

        // Эффект плавающих элементов
        this.addEffect('float', {
            selector: '[data-float]',
            handler: (element, scrollInfo) => {
                const amplitude = parseFloat(element.dataset.float) || 15;
                const frequency = parseFloat(element.dataset.floatFrequency) || 0.002;
                const offset = Math.sin(scrollInfo.y * frequency) * amplitude;
                element.style.transform = `translate3d(0, ${offset}px, 0)`;
            }
        });

        // Эффект параллакса для текста
        this.addEffect('text-split', {
            selector: '[data-text-split]',
            handler: (element, scrollInfo) => {
                if (!element.children.length) {
                    this.splitText(element);
                }

                Array.from(element.children).forEach((char, i) => {
                    const speed = 0.1 + (i * 0.01);
                    const offset = scrollInfo.y * speed;
                    const rotation = Math.sin(scrollInfo.y * 0.002 + i * 0.2) * 5;
                    char.style.transform = `
                        translate3d(0, ${offset}px, 0)
                        rotate(${rotation}deg)
                    `;
                });
            }
        });

        // Эффект скорости прокрутки
        this.addEffect('scroll-speed', {
            selector: '[data-scroll-speed]',
            handler: (element, scrollInfo) => {
                const intensity = parseFloat(element.dataset.scrollSpeed) || 1;
                const scale = 1 + (Math.min(Math.abs(scrollInfo.speed), 50) * 0.01 * intensity);
                const blur = Math.min(Math.abs(scrollInfo.speed) * 0.1 * intensity, 5);
                
                element.style.transform = `scale(${scale})`;
                element.style.filter = `blur(${blur}px)`;
            }
        });
    }

    addEffect(name, config) {
        this.effects.set(name, {
            elements: document.querySelectorAll(config.selector),
            handler: config.handler
        });
    }

    splitText(element) {
        const text = element.textContent;
        element.textContent = '';
        text.split('').forEach(char => {
            const span = document.createElement('span');
            span.textContent = char;
            span.style.display = 'inline-block';
            element.appendChild(span);
        });
    }

    bindEvents() {
        window.addEventListener('scroll', () => {
            if (!this.isRunning) {
                this.isRunning = true;
                this.rafId = requestAnimationFrame(() => this.update());
            }
        }, { passive: true });

        window.addEventListener('resize', this.app.utils.debounce(() => {
            this.effects.forEach(effect => {
                effect.elements = document.querySelectorAll(effect.selector);
            });
        }, 150));
    }

    update() {
        const scrollY = window.scrollY;
        const scrollDelta = scrollY - this.lastScrollY;
        
        const scrollInfo = {
            y: scrollY,
            delta: scrollDelta,
            direction: scrollDelta > 0 ? 'down' : 'up',
            speed: Math.abs(scrollDelta)
        };

        this.effects.forEach(effect => {
            effect.elements.forEach(element => {
                effect.handler(element, scrollInfo);
            });
        });

        this.lastScrollY = scrollY;
        this.isRunning = false;
    }

    startAnimation() {
        const animate = () => {
            if (!document.hidden) {
                this.effects.forEach(effect => {
                    effect.elements.forEach(element => {
                        if (this.isElementInViewport(element)) {
                            effect.handler(element, {
                                y: this.lastScrollY,
                                delta: 0,
                                direction: this.scrollDirection,
                                speed: this.scrollSpeed
                            });
                        }
                    });
                });
            }
            this.rafId = requestAnimationFrame(animate);
        };

        animate();
    }

    isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top < window.innerHeight &&
            rect.bottom > 0
        );
    }

    destroy() {
        if (this.rafId) {
            cancelAnimationFrame(this.rafId);
        }
        window.removeEventListener('scroll');
        window.removeEventListener('resize');
    }
} 