export class FormController {
    constructor(app) {
        this.app = app;
        this.forms = new Map();
        this.validators = new Map();
        this.customMessages = new Map();

        this.init();
    }

    init() {
        this.setupValidators();
        this.setupForms();
        this.bindEvents();
    }

    setupValidators() {
        // Базовые валидаторы
        this.addValidator('required', (value) => {
            return value.trim().length > 0;
        });

        this.addValidator('email', (value) => {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
        });

        this.addValidator('minLength', (value, params) => {
            return value.length >= params.min;
        });

        this.addValidator('maxLength', (value, params) => {
            return value.length <= params.max;
        });

        this.addValidator('pattern', (value, params) => {
            return new RegExp(params.pattern).test(value);
        });

        // Кастомные валидаторы
        this.addValidator('url', (value) => {
            try {
                new URL(value);
                return true;
            } catch {
                return false;
            }
        });

        this.addValidator('phone', (value) => {
            return /^\+?[\d\s-()]{10,}$/.test(value);
        });
    }

    setupForms() {
        document.querySelectorAll('form[data-validate]').forEach(form => {
            const formId = form.id || `form_${Math.random().toString(36).substr(2, 9)}`;
            this.forms.set(formId, {
                element: form,
                fields: this.getFormFields(form),
                state: {
                    isValid: false,
                    isSubmitting: false,
                    errors: new Map()
                }
            });
        });
    }

    getFormFields(form) {
        const fields = new Map();
        form.querySelectorAll('[data-validate]').forEach(field => {
            const rules = this.parseValidationRules(field.dataset.validate);
            fields.set(field, {
                rules,
                errors: [],
                isValid: true
            });
        });
        return fields;
    }

    parseValidationRules(rulesString) {
        return rulesString.split('|').map(rule => {
            const [name, params] = rule.split(':');
            return {
                name,
                params: params ? JSON.parse(`{${params}}`) : {}
            };
        });
    }

    addValidator(name, fn) {
        this.validators.set(name, fn);
    }

    setCustomMessage(rule, message) {
        this.customMessages.set(rule, message);
    }

    bindEvents() {
        this.forms.forEach((form, formId) => {
            // Валидация при вводе
            form.fields.forEach((fieldData, field) => {
                field.addEventListener('input', () => {
                    this.validateField(field, fieldData);
                    this.updateFormState(formId);
                });

                field.addEventListener('blur', () => {
                    this.validateField(field, fieldData, true);
                    this.updateFormState(formId);
                });
            });

            // Обработка отправки формы
            form.element.addEventListener('submit', async (e) => {
                e.preventDefault();
                if (await this.handleSubmit(formId)) {
                    // Форма валидна, можно отправлять
                    this.submitForm(formId);
                }
            });
        });
    }

    async validateField(field, fieldData, showErrors = false) {
        const value = field.value;
        const errors = [];

        for (const rule of fieldData.rules) {
            const validator = this.validators.get(rule.name);
            if (validator && !validator(value, rule.params)) {
                errors.push(this.getErrorMessage(rule, field));
            }
        }

        fieldData.errors = errors;
        fieldData.isValid = errors.length === 0;

        if (showErrors) {
            this.showFieldErrors(field, errors);
        }

        return fieldData.isValid;
    }

    getErrorMessage(rule, field) {
        const customMessage = this.customMessages.get(rule.name);
        if (customMessage) {
            return typeof customMessage === 'function' 
                ? customMessage(field, rule.params)
                : customMessage;
        }

        return this.app.i18n.translate(`validation.${rule.name}`, rule.params);
    }

    showFieldErrors(field, errors) {
        // Удаляем старые сообщения об ошибках
        const container = field.parentElement;
        container.querySelectorAll('.error-message').forEach(el => el.remove());

        // Добавляем новые сообщения
        if (errors.length > 0) {
            const errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            errorElement.textContent = errors[0]; // Показываем первую ошибку
            container.appendChild(errorElement);
            field.classList.add('is-invalid');
        } else {
            field.classList.remove('is-invalid');
        }
    }

    updateFormState(formId) {
        const form = this.forms.get(formId);
        let isValid = true;
        const errors = new Map();

        form.fields.forEach((fieldData, field) => {
            if (!fieldData.isValid) {
                isValid = false;
                errors.set(field.name, fieldData.errors);
            }
        });

        form.state.isValid = isValid;
        form.state.errors = errors;

        // Обновляем состояние кнопки отправки
        const submitButton = form.element.querySelector('[type="submit"]');
        if (submitButton) {
            submitButton.disabled = !isValid || form.state.isSubmitting;
        }
    }

    async handleSubmit(formId) {
        const form = this.forms.get(formId);
        form.state.isSubmitting = true;
        this.updateFormState(formId);

        // Валидируем все поля
        const validations = Array.from(form.fields.entries()).map(
            ([field, fieldData]) => this.validateField(field, fieldData, true)
        );

        const results = await Promise.all(validations);
        const isValid = results.every(result => result);

        form.state.isSubmitting = false;
        this.updateFormState(formId);

        return isValid;
    }

    async submitForm(formId) {
        const form = this.forms.get(formId);
        try {
            const formData = new FormData(form.element);
            const response = await fetch(form.element.action, {
                method: form.element.method || 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            this.handleSuccess(formId);
        } catch (error) {
            this.handleError(formId, error);
        }
    }

    handleSuccess(formId) {
        const form = this.forms.get(formId);
        form.element.reset();
        this.app.events.emit('form:success', { formId });
    }

    handleError(formId, error) {
        this.app.events.emit('form:error', { formId, error });
    }

    destroy() {
        this.forms.forEach((form) => {
            form.element.removeEventListener('submit');
            form.fields.forEach((_, field) => {
                field.removeEventListener('input');
                field.removeEventListener('blur');
            });
        });
    }
} 