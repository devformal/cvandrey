document.addEventListener('DOMContentLoaded', () => {
    const parallaxBg = document.createElement('div');
    parallaxBg.className = 'parallax-bg';
    document.body.appendChild(parallaxBg);

    // Конфигурация элементов
    const elements = [
        { size: 400, speed: 0.03, blur: 60, opacity: 0.3, color: 'var(--accent-gradient-1)' },
        { size: 300, speed: 0.05, blur: 40, opacity: 0.2, color: 'var(--accent-gradient-2)' },
        { size: 250, speed: 0.07, blur: 30, opacity: 0.15, color: 'var(--accent-color)' }
    ];

    // Создаем parallax элементы
    elements.forEach(config => {
        const element = document.createElement('div');
        element.className = 'parallax-element';
        element.style.cssText = `
            width: ${config.size}px;
            height: ${config.size}px;
            left: ${Math.random() * 80 + 10}%;
            top: ${Math.random() * 80 + 10}%;
            filter: blur(${config.blur}px);
            opacity: ${config.opacity};
            background: radial-gradient(circle at center, 
                ${config.color}, 
                transparent 70%
            );
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        `;
        parallaxBg.appendChild(element);
    });

    let mouseX = 0;
    let mouseY = 0;
    let currentX = 0;
    let currentY = 0;

    // Плавное обновление позиции
    const updatePosition = () => {
        const elements = document.querySelectorAll('.parallax-element');
        
        elements.forEach((element, index) => {
            // Плавное движение к целевой позиции
            currentX += (mouseX - currentX) * elements[index].speed;
            currentY += (mouseY - currentY) * elements[index].speed;

            const translateX = currentX * (index + 1) * 20;
            const translateY = currentY * (index + 1) * 20;
            const scale = 1 + Math.abs(mouseX + mouseY) * 0.05;

            element.style.transform = `
                translate(${translateX}px, ${translateY}px) 
                scale(${scale})
                rotate(${translateX * 0.05}deg)
            `;
        });

        requestAnimationFrame(updatePosition);
    };

    // Обработчик движения мыши
    document.addEventListener('mousemove', (e) => {
        mouseX = (e.clientX - window.innerWidth / 2) / window.innerWidth;
        mouseY = (e.clientY - window.innerHeight / 2) / window.innerHeight;
    });

    // Обработчик прокрутки
    document.addEventListener('scroll', () => {
        const scrolled = window.scrollY / window.innerHeight;
        document.querySelectorAll('.parallax-element').forEach((element, index) => {
            const translateY = scrolled * (index + 1) * 50;
            element.style.transform += ` translateY(${translateY}px)`;
        });
    });

    // Начинаем анимацию
    updatePosition();

    // Оптимизация производительности
    let timeout;
    window.addEventListener('resize', () => {
        if (timeout) clearTimeout(timeout);
        timeout = setTimeout(() => {
            document.querySelectorAll('.parallax-element').forEach(element => {
                element.style.transition = 'none';
                element.style.left = `${Math.random() * 80 + 10}%`;
                element.style.top = `${Math.random() * 80 + 10}%`;
                setTimeout(() => element.style.transition = 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)', 100);
            });
        }, 100);
    });

    const avatar = document.querySelector('.profile-avatar');
    const container = document.querySelector('.avatar-container');
    let scrollPosition = 0;
    let ticking = false;

    // Коэффициенты для анимации
    const ROTATION_COEFFICIENT = 0.02;
    const MOVEMENT_COEFFICIENT = 0.05;
    const MAX_ROTATION = 15;
    const MAX_MOVEMENT = 20;

    function updateAvatarTransform() {
        // Получаем текущую позицию скролла
        const scrollDelta = window.scrollY - scrollPosition;
        scrollPosition = window.scrollY;

        if (avatar && container) {
            // Вычисляем углы поворота
            const rotateX = Math.min(Math.max(-MAX_ROTATION, scrollDelta * ROTATION_COEFFICIENT), MAX_ROTATION);
            const rotateY = Math.min(Math.max(-MAX_ROTATION, -scrollDelta * ROTATION_COEFFICIENT), MAX_ROTATION);

            // Вычисляем смещение
            const translateX = Math.min(Math.max(-MAX_MOVEMENT, -scrollDelta * MOVEMENT_COEFFICIENT), MAX_MOVEMENT);
            const translateY = Math.min(Math.max(-MAX_MOVEMENT, scrollDelta * MOVEMENT_COEFFICIENT), MAX_MOVEMENT);

            // Применяем трансформацию
            avatar.style.transform = `
                rotateX(${rotateX}deg)
                rotateY(${rotateY}deg)
                translate(${translateX}px, ${translateY}px)
                scale(${1 + Math.abs(scrollDelta) * 0.001})
            `;

            // Анимируем свечение
            container.style.setProperty('--glow-strength', `${Math.abs(scrollDelta) * 0.01}`);
            container.style.setProperty('--glow-spread', `${10 + Math.abs(scrollDelta) * 0.1}px`);
        }

        ticking = false;
    }

    // Обработчик скролла с throttling
    window.addEventListener('scroll', () => {
        if (!ticking) {
            requestAnimationFrame(() => {
                updateAvatarTransform();
                ticking = false;
            });
            ticking = true;
        }
    });

    // Сброс позиции при остановке скролла
    let scrollTimeout;
    window.addEventListener('scroll', () => {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(() => {
            if (avatar) {
                avatar.style.transform = `
                    rotateX(0deg)
                    rotateY(0deg)
                    translate(0, 0)
                    scale(1)
                `;
            }
        }, 150);
    });

    // Добавляем интерактивность при движении мыши
    if (avatar && container) {
        container.addEventListener('mousemove', (e) => {
            const rect = container.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;

            avatar.style.transform = `
                rotateY(${x * 0.02}deg)
                rotateX(${-y * 0.02}deg)
                scale(1.05)
            `;
        });

        container.addEventListener('mouseleave', () => {
            avatar.style.transform = `
                rotateY(0)
                rotateX(0)
                scale(1)
            `;
        });
    }

    // Добавим debounce для оптимизации производительности
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Используем IntersectionObserver для оптимизации анимаций
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '50px'
    });
}); 