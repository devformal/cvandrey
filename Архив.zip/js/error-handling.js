window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    // Можно добавить отправку ошибок в аналитику
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
}); 