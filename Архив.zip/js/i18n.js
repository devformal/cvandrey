const translations = {
    en: {
        // Заголовки
        title: "Research Assistant · Linguistics",
        location: "Nova Gorica, Slovenia",
        university: "University of Nova Gorica",
        
        // Навигация
        scholar: "Scholar",
        researchgate: "ResearchGate",
        linkedin: "LinkedIn",
        telegram: "Telegram",
        
        // Статистика
        conferenceTalks: "Conference Talks",
        publications: "Publications",
        languages: "Languages",
        
        // Разделы
        researchFocus: "Research Focus",
        skillsExpertise: "Skills & Expertise",
        selectedPublications: "Selected Publications",
        
        // Навыки
        researchMethods: "Research Methods",
        statisticalAnalysis: "Statistical Analysis",
        experimentalDesign: "Experimental Design",
        eegResearch: "EEG Research",
        programming: "Programming",
        
        // Уровни владения
        native: "Native",
        advanced: "Advanced",
        intermediate: "Intermediate",
        
        // Копирование
        copyEmail: "Email copied to clipboard!",
        copy: "Copy",

        // Статистика
        statsTalks: "Conference Talks",
        statsPublications: "Publications",
        statsLanguages: "Countries",

        // Основные блоки
        researchInterests: {
            title: "Research Interests",
            description: "My work focuses on psycholinguistics, with an emphasis on syntax, information structure, and phonology. Specifically, I investigate scrambling, word order, and the syntax of Russian particles, as well as the comprehension and production of information structure.",
            tags: [
                "Psycholinguistics",
                "Syntax",
                "Phonology",
                "Information Structure"
            ]
        },

        methods: {
            title: "Methods",
            description: "I employ both experimental (behavioral and neurophysiological) and theoretical approaches to study these linguistic phenomena. My research integrates diverse methodologies to examine language processing and its underlying structures.",
            tags: [
                "Experimental",
                "Behavioral",
                "Neurophysiological",
                "Theoretical"
            ]
        },

        dataAnalysis: {
            title: "Analiza podatkov in orodja",
            description: "Uporabljam napredna orodja za zbiranje in analizo podatkov, vključno z R in RStudio za statistično modeliranje, Eyelink 1000 za sledenje očem ter BrainRecorder in BrainAnalyzer za EEG eksperimente. Delam tudi z jezikoslovnimi orodji kot so UDPipe, Mystem, Praat in ELAN.",
            tags: [
                "R & RStudio",
                "Eyelink 1000",
                "BrainAnalyzer",
                "Praat",
                "ELAN"
            ]
        },

        // Публикации
        publications: {
            paper1: {
                title: "Vloga načina predstavitve pri procesiranju stavkov",
                description: "Raziskava o tem, ali je slušno razumevanje bolj ali manj zahtevno od bralnega razumevanja, ki kaže, da način predstavitve vpliva na odzivne čase, ne pa na natančnost razumevanja.",
                tags: ["Psiholingvistika", "Procesiranje stavkov", "Ruski jezik"],
                year: "2023",
                publisher: "ExLing Society"
            },
            paper2: {
                title: "O razlikah med hiperbatonom in inverzijo",
                description: "Analiza strukturnih in psiholingvističnih razlik med hiperbatonom in inverzijo, ki dokazuje, da se ti pojavi razlikujejo tako v strukturnih lastnostih kot v kompleksnosti procesiranja.",
                tags: ["Stilistika", "Sintaksa", "Psiholingvistika"],
                year: "2023",
                publisher: "Ruska gramatika v dialogu znanstvenih šol"
            },
            paper3: {
                title: "Test razumevanja stavkov za ruščino: orodje za ocenjevanje sintaktične kompetence",
                description: "Razvoj in validacija celovitega testa za ocenjevanje sintaktične kompetence v ruščini, s poudarkom na različnih vidikih razumevanja in procesiranja stavkov.",
                tags: ["Psiholingvistika", "Ruski jezik", "Sintaktično ocenjevanje"],
                year: "2023",
                publisher: "Frontiers in Psychology"
            }
        },

        // Навыки
        skills: {
            research: {
                title: "Raziskovalne metode",
                items: {
                    statistical: {
                        name: "Statistična analiza",
                        level: "Napredno"
                    },
                    experimental: {
                        name: "Načrtovanje poskusov",
                        level: "Napredno"
                    },
                    eeg: {
                        name: "EEG raziskave",
                        level: "Srednje"
                    }
                }
            },
            programming: {
                title: "Programiranje",
                items: {
                    python: {
                        name: "Python (NumPy, Pandas)",
                        level: "Napredno"
                    },
                    r: {
                        name: "R (tidyverse, lme4)",
                        level: "Napredno"
                    },
                    matlab: {
                        name: "MATLAB",
                        level: "Srednje"
                    }
                }
            },
            languages: {
                title: "Languages",
                items: {
                    russian: {
                        name: "Russian",
                        level: "Native"
                    },
                    english: {
                        name: "English",
                        level: "C2"
                    },
                    german: {
                        name: "German",
                        level: "B2"
                    },
                    slovenian: {
                        name: "Slovenian",
                        level: "A2"
                    }
                }
            }
        },

        // Опыт работы
        experience: {
            industry: {
                title: "Delovne izkušnje",
                positions: {
                    teamLead: {
                        title: "Vodja ekipe za oblikovanje navodil",
                        company: "Plow",
                        period: "02.2023 - 12.2023",
                        duties: [
                            "Intervjuji s strankami in strokovnjaki",
                            "Oblikovanje strukture tečajev (MindMeister, Miro)",
                            "Vodenje ekipe mlajših oblikovalcev navodil",
                            "Razvoj ocenjevalnih instrumentov"
                        ]
                    },
                    tutor: {
                        title: "Zasebni jezikovni učitelj",
                        period: "2016 - 2023",
                        duties: [
                            "Različne starostne skupine",
                            "Interaktivni pristopi k učenju",
                            "Priprava na IELTS in TOEFL"
                        ]
                    }
                }
            }
        },

        // Интерфейсные элементы
        interface: {
            viewPaper: "Ogled članka",
            copyEmail: "E-pošta kopirana v odložišče!",
            readMore: "Preberi več",
            showDetails: "Pokaži podrobnosti",
            hideDetails: "Skrij podrobnosti",
            loading: "Nalaganje...",
            contactMe: "Kontaktirajte me",
            downloadCV: "Prenos CV",
            viewProfile: "Ogled profila"
        }
    },
    sl: {
        // Заголовки
        title: "Raziskovalni asistent · Jezikoslovje",
        location: "Nova Gorica, Slovenija",
        university: "Univerza v Novi Gorici",
        
        // Навигация
        scholar: "Scholar",
        researchgate: "ResearchGate",
        linkedin: "LinkedIn",
        telegram: "Telegram",
        
        // Статистика
        conferenceTalks: "Konferenčni nastopi",
        publications: "Publikacije",
        languages: "Jeziki",
        
        // Разделы
        researchFocus: "Raziskovalno področje",
        skillsExpertise: "Znanja in veščine",
        selectedPublications: "Izbrane publikacije",
        
        // Навыки
        researchMethods: "Raziskovalne metode",
        statisticalAnalysis: "Statistična analiza",
        experimentalDesign: "Načrtovanje poskusov",
        eegResearch: "EEG raziskave",
        programming: "Programiranje",
        
        // Уровни владения
        native: "Materni jezik",
        advanced: "Napredno",
        intermediate: "Srednje",
        
        // Копирование
        copyEmail: "E-pošta kopirana v odložišče!",
        copy: "Kopiraj",

        // Статистика
        statsTalks: "Konferenčni nastopi",
        statsPublications: "Publikacije",
        statsLanguages: "Držav",

        // Основные блоки
        researchInterests: {
            title: "Raziskovalni interesi",
            description: "Moje delo se osredotoča na psiholingvistiko, s poudarkom na sintaksi, informacijski strukturi in fonologiji. Posebej raziskujem premikanje besed, besedni red in sintakso ruskih členkov, pa tudi razumevanje in tvorjenje informacijske strukture. Poleg tega raziskujem fonološke pojave, vključno z naglasom in poudarkom.",
            tags: [
                "Psiholingvistika",
                "Sintaksa",
                "Fonologija",
                "Informacijska struktura"
            ]
        },

        methods: {
            title: "Metode",
            description: "Pri raziskovanju teh jezikovnih pojavov uporabljam tako eksperimentalne (vedenjske in nevrofiziološke) kot teoretične pristope. Moje raziskave združujejo različne metodologije za preučevanje jezikovnega procesiranja in njegovih osnovnih struktur.",
            tags: [
                "Eksperimentalno",
                "Vedenjsko",
                "Nevrofiziološko",
                "Teoretično"
            ]
        },

        dataAnalysis: {
            title: "Analiza podatkov in orodja",
            description: "Uporabljam napredna orodja za zbiranje in analizo podatkov, vključno z R in RStudio za statistično modeliranje, Eyelink 1000 za sledenje očem ter BrainRecorder in BrainAnalyzer za EEG eksperimente. Delam tudi z jezikoslovnimi orodji kot so UDPipe, Mystem, Praat in ELAN.",
            tags: [
                "R & RStudio",
                "Eyelink 1000",
                "BrainAnalyzer",
                "Praat",
                "ELAN"
            ]
        },

        // Публикации
        publications: {
            paper1: {
                title: "Vloga načina predstavitve pri procesiranju stavkov",
                description: "Raziskava o tem, ali je slušno razumevanje bolj ali manj zahtevno od bralnega razumevanja, ki kaže, da način predstavitve vpliva na odzivne čase, ne pa na natančnost razumevanja.",
                tags: ["Psiholingvistika", "Procesiranje stavkov", "Ruski jezik"],
                year: "2023",
                publisher: "ExLing Society"
            },
            paper2: {
                title: "O razlikah med hiperbatonom in inverzijo",
                description: "Analiza strukturnih in psiholingvističnih razlik med hiperbatonom in inverzijo, ki dokazuje, da se ti pojavi razlikujejo tako v strukturnih lastnostih kot v kompleksnosti procesiranja.",
                tags: ["Stilistika", "Sintaksa", "Psiholingvistika"],
                year: "2023",
                publisher: "Ruska gramatika v dialogu znanstvenih šol"
            },
            paper3: {
                title: "Test razumevanja stavkov za ruščino: orodje za ocenjevanje sintaktične kompetence",
                description: "Razvoj in validacija celovitega testa za ocenjevanje sintaktične kompetence v ruščini, s poudarkom na različnih vidikih razumevanja in procesiranja stavkov.",
                tags: ["Psiholingvistika", "Ruski jezik", "Sintaktično ocenjevanje"],
                year: "2023",
                publisher: "Frontiers in Psychology"
            }
        },

        // Навыки
        skills: {
            research: {
                title: "Raziskovalne metode",
                items: {
                    statistical: {
                        name: "Statistična analiza",
                        level: "Napredno"
                    },
                    experimental: {
                        name: "Načrtovanje poskusov",
                        level: "Napredno"
                    },
                    eeg: {
                        name: "EEG raziskave",
                        level: "Srednje"
                    }
                }
            },
            programming: {
                title: "Programiranje",
                items: {
                    python: {
                        name: "Python (NumPy, Pandas)",
                        level: "Napredno"
                    },
                    r: {
                        name: "R (tidyverse, lme4)",
                        level: "Napredno"
                    },
                    matlab: {
                        name: "MATLAB",
                        level: "Srednje"
                    }
                }
            },
            languages: {
                title: "Jeziki",
                items: {
                    russian: {
                        name: "Ruščina",
                        level: "Materni jezik"
                    },
                    english: {
                        name: "Angleščina",
                        level: "C2"
                    },
                    german: {
                        name: "Nemščina",
                        level: "B2"
                    },
                    slovenian: {
                        name: "Slovenščina",
                        level: "A2"
                    }
                }
            }
        },

        // Опыт работы
        experience: {
            industry: {
                title: "Delovne izkušnje",
                positions: {
                    teamLead: {
                        title: "Vodja ekipe za oblikovanje navodil",
                        company: "Plow",
                        period: "02.2023 - 12.2023",
                        duties: [
                            "Intervjuji s strankami in strokovnjaki",
                            "Oblikovanje strukture tečajev (MindMeister, Miro)",
                            "Vodenje ekipe mlajših oblikovalcev navodil",
                            "Razvoj ocenjevalnih instrumentov"
                        ]
                    },
                    tutor: {
                        title: "Zasebni jezikovni učitelj",
                        period: "2016 - 2023",
                        duties: [
                            "Različne starostne skupine",
                            "Interaktivni pristopi k učenju",
                            "Priprava na IELTS in TOEFL"
                        ]
                    }
                }
            }
        },

        // Интерфейсные элементы
        interface: {
            viewPaper: "Ogled članka",
            copyEmail: "E-pošta kopirana v odložišče!",
            readMore: "Preberi več",
            showDetails: "Pokaži podrobnosti",
            hideDetails: "Skrij podrobnosti",
            loading: "Nalaganje...",
            contactMe: "Kontaktirajte me",
            downloadCV: "Prenos CV",
            viewProfile: "Ogled profila"
        }
    },
    ru: {
        // Заголовки
        title: "Исследовательская помощь · Лингвистика",
        location: "Новая Горица, Словения",
        university: "Университет Новой Горицы",
        
        // Навигация
        scholar: "Шолар",
        researchgate: "ResearchGate",
        linkedin: "LinkedIn",
        telegram: "Telegram",
        
        // Статистика
        conferenceTalks: "Доклады на конференциях",
        publications: "Публикации",
        languages: "Языки",
        
        // Разделы
        researchFocus: "Исследовательское направление",
        skillsExpertise: "Знания и навыки",
        selectedPublications: "Выбранные публикации",
        
        // Навыки
        researchMethods: "Исследовательские методы",
        statisticalAnalysis: "Статистический анализ",
        experimentalDesign: "Экспериментальное проектирование",
        eegResearch: "ЭЭГ-исследования",
        programming: "Программирование",
        
        // Уровни владения
        native: "Родной",
        advanced: "Продвинутый",
        intermediate: "Средний",
        
        // Копирование
        copyEmail: "Email скопирован в буфер обмена!",
        copy: "Копировать",

        // Статистика
        statsTalks: "Доклады на конференциях",
        statsPublications: "Публикации",
        statsLanguages: "Страны",

        // Основные блоки
        researchInterests: {
            title: "Исследовательские интересы",
            description: "Моя работа сосредоточена на психолингвистике, с акцентом на синтаксисе, информационной структуре и фонологии. В частности, я исследую перестановку слов, порядок слов и синтаксис русских частиц, а также понимание и производство информационной структуры.",
            tags: [
                "Психолингвистика",
                "Синтаксис",
                "Фонология",
                "Информационная структура"
            ]
        },

        methods: {
            title: "Методы",
            description: "Я использую как экспериментальные (поведенческие и неврофизиологические), так и теоретические подходы для изучения этих языковых явлений. Мои исследования объединяют различные методологии для изучения языкового процесса и его основных структур.",
            tags: [
                "Экспериментальный",
                "Поведенческий",
                "Неврофизиологический",
                "Теоретический"
            ]
        },

        dataAnalysis: {
            title: "Анализ данных и инструментов",
            description: "Я использую современные инструменты для сбора и анализа данных, включая R и RStudio для статистического моделирования, Eyelink 1000 для отслеживания глаз и BrainRecorder и BrainAnalyzer для экспериментов с ЭЭГ. Я также работаю с лингвистическими инструментами, такими как UDPipe, Mystem, Praat и ELAN.",
            tags: [
                "R & RStudio",
                "Eyelink 1000",
                "BrainAnalyzer",
                "Praat",
                "ELAN"
            ]
        },

        // Публикации
        publications: {
            paper1: {
                title: "Роль способа представления при обработке предложений",
                description: "Исследование того, является ли устное восприятие более или менее требовательным по сравнению с письменным восприятием, что показывает, что способ представления влияет на время ответа, но не на точность восприятия.",
                tags: ["Психолингвистика", "Обработка предложений", "Русский язык"],
                year: "2023",
                publisher: "ExLing Society"
            },
            paper2: {
                title: "О различиях между гиперболой и инверсией",
                description: "Анализ структурных и психолингвистических различий между гиперболой и инверсией, что доказывает, что эти явления различаются как в структурных свойствах, так и в сложности обработки.",
                tags: ["Стилистика", "Синтаксис", "Психолингвистика"],
                year: "2023",
                publisher: "Русская грамматика в диалоге научных школ"
            },
            paper3: {
                title: "Тест понимания предложений для русского языка: инструмент для оценки синтаксической компетенции",
                description: "Разработка и валидация полного теста для оценки синтаксической компетенции на русском языке, с акцентом на различных аспектах понимания и обработки предложений.",
                tags: ["Психолингвистика", "Русский язык", "Синтаксическая оценка"],
                year: "2023",
                publisher: "Frontiers in Psychology"
            }
        },

        // Навыки
        skills: {
            research: {
                title: "Исследовательские методы",
                items: {
                    statistical: {
                        name: "Статистический анализ",
                        level: "Продвинутый"
                    },
                    experimental: {
                        name: "Экспериментальное проектирование",
                        level: "Продвинутый"
                    },
                    eeg: {
                        name: "ЭЭГ-исследования",
                        level: "Средний"
                    }
                }
            },
            programming: {
                title: "Программирование",
                items: {
                    python: {
                        name: "Python (NumPy, Pandas)",
                        level: "Продвинутый"
                    },
                    r: {
                        name: "R (tidyverse, lme4)",
                        level: "Продвинутый"
                    },
                    matlab: {
                        name: "MATLAB",
                        level: "Средний"
                    }
                }
            },
            languages: {
                title: "Языки",
                items: {
                    russian: {
                        name: "Русский",
                        level: "Родной язык"
                    },
                    english: {
                        name: "Английский",
                        level: "C2"
                    },
                    german: {
                        name: "Немецкий",
                        level: "B2"
                    },
                    slovenian: {
                        name: "Словенский",
                        level: "A2"
                    }
                }
            }
        },

        // Опыт работы
        experience: {
            industry: {
                title: "Отраслевой опыт",
                positions: {
                    teamLead: {
                        title: "Лидер команды для разработки инструкций",
                        company: "Plow",
                        period: "02.2023 - 12.2023",
                        duties: [
                            "Собеседования с клиентами и специалистами",
                            "Разработка структуры курсов (MindMeister, Miro)",
                            "Руководство команды молодых разработчиков инструкций",
                            "Разработка оценочных инструментов"
                        ]
                    },
                    tutor: {
                        title: "Частный преподаватель языка",
                        period: "2016 - 2023",
                        duties: [
                            "Различные возрастные группы",
                            "Интерактивные подходы к обучению",
                            "Подготовка к IELTS и TOEFL"
                        ]
                    }
                }
            }
        },

        // Интерфейсные элементы
        interface: {
            viewPaper: "Просмотр статьи",
            copyEmail: "Email скопирован в буфер обмена!",
            readMore: "Читать больше",
            showDetails: "Показать подробности",
            hideDetails: "Скрыть подробности",
            loading: "Загрузка...",
            contactMe: "Свяжитесь со мной",
            downloadCV: "Скачать CV",
            viewProfile: "Просмотр профиля"
        }
    },
    de: {
        // Заголовки
        title: "Forschungshelfer · Linguistik",
        location: "Nova Gorica, Slowenien",
        university: "Universität Nova Gorica",
        
        // Навигация
        scholar: "Scholar",
        researchgate: "ResearchGate",
        linkedin: "LinkedIn",
        telegram: "Telegram",
        
        // Статистика
        conferenceTalks: "Vorträge auf Konferenzen",
        publications: "Publikationen",
        languages: "Sprachen",
        
        // Разделы
        researchFocus: "Forschungsgebiet",
        skillsExpertise: "Kenntnisse und Fähigkeiten",
        selectedPublications: "Ausgewählte Publikationen",
        
        // Навыки
        researchMethods: "Forschungsverfahren",
        statisticalAnalysis: "Statistische Analyse",
        experimentalDesign: "Experimentelle Gestaltung",
        eegResearch: "EEG-Untersuchungen",
        programming: "Programmierung",
        
        // Уровни владения
        native: "Muttersprache",
        advanced: "Fortgeschritten",
        intermediate: "Mittelstufe",
        
        // Копирование
        copyEmail: "Email kopiert in die Zwischenablage!",
        copy: "Kopieren",

        // Статистика
        statsTalks: "Vorträge auf Konferenzen",
        statsPublications: "Publikationen",
        statsLanguages: "Länder",

        // Основные блоки
        researchInterests: {
            title: "Forschungsinteressen",
            description: "Meine Arbeit konzentriert sich auf die Psycholinguistik, mit dem Schwerpunkt auf Syntax, Informationsstruktur und Phonologie. Speziell untersuche ich die Umstellung von Wörtern, Satzgliederung und Syntax der russischen Teile, sowie die Verständigung und Erstellung der Informationsstruktur.",
            tags: [
                "Psycholinguistik",
                "Syntax",
                "Phonologie",
                "Informationsstruktur"
            ]
        },

        methods: {
            title: "Methoden",
            description: "Ich verwende sowohl experimentelle (behaviorale und nevrofiziologe) als auch theoretische Ansätze, um diese sprachlichen Phänomene zu studieren. Meine Forschungen integrieren verschiedene Methodologien zur Untersuchung des sprachlichen Verarbeitungsprozesses und seiner grundlegenden Strukturen.",
            tags: [
                "Experimentell",
                "Behavioral",
                "Nevrofiziologe",
                "Theoretisch"
            ]
        },

        dataAnalysis: {
            title: "Datenanalyse und Instrumente",
            description: "Ich verwende moderne Instrumente zur Datenerfassung und -analyse, einschließlich R und RStudio für statistische Modellierung, Eyelink 1000 für Augenbewegungssignale und BrainRecorder und BrainAnalyzer für EEG-Experimente. Ich arbeite auch mit linguistischen Instrumenten wie UDPipe, Mystem, Praat und ELAN.",
            tags: [
                "R & RStudio",
                "Eyelink 1000",
                "BrainAnalyzer",
                "Praat",
                "ELAN"
            ]
        },

        // Publikationen
        publications: {
            paper1: {
                title: "Die Rolle des Darstellungsmodus bei der Verarbeitung von Sätzen",
                description: "Eine Untersuchung darüber, ob das lautlose Verstehen mehr oder weniger anspruchsvoll ist als das schriftliche Verstehen, das zeigt, dass der Darstellungsmodus die Reaktionszeiten beeinflusst, aber nicht die Verständigung genauigkeit.",
                tags: ["Psycholinguistik", "Satzverarbeitung", "Russischer Sprache"],
                year: "2023",
                publisher: "ExLing Society"
            },
            paper2: {
                title: "Über die Unterschiede zwischen Hyperbel und Inversion",
                description: "Eine Analyse der strukturellen und psycholinguistischen Unterschiede zwischen Hyperbel und Inversion, die zeigt, dass diese Phänomene sich sowohl in strukturellen als auch in der Komplexität der Verarbeitung unterscheiden.",
                tags: ["Stilistik", "Syntax", "Psycholinguistik"],
                year: "2023",
                publisher: "Russische Grammatik im Dialog der Wissenschaftlichen Schulen"
            },
            paper3: {
                title: "Test der Verständigung von Sätzen für die Russische: Instrument zur Beurteilung der Syntaxkompetenz",
                description: "Entwicklung und Validierung eines vollständigen Tests zur Beurteilung der Syntaxkompetenz in der Russischen, mit dem Fokus auf verschiedenen Aspekten der Verständigung und der Satzverarbeitung.",
                tags: ["Psycholinguistik", "Russische Sprache", "Syntaxbewertung"],
                year: "2023",
                publisher: "Frontiers in Psychology"
            }
        },

        // Fähigkeiten
        skills: {
            research: {
                title: "Forschungsverfahren",
                items: {
                    statistical: {
                        name: "Statistische Analyse",
                        level: "Fortgeschritten"
                    },
                    experimental: {
                        name: "Experimentelle Gestaltung",
                        level: "Fortgeschritten"
                    },
                    eeg: {
                        name: "EEG-Untersuchungen",
                        level: "Mittelstufe"
                    }
                }
            },
            programming: {
                title: "Programmierung",
                items: {
                    python: {
                        name: "Python (NumPy, Pandas)",
                        level: "Fortgeschritten"
                    },
                    r: {
                        name: "R (tidyverse, lme4)",
                        level: "Fortgeschritten"
                    },
                    matlab: {
                        name: "MATLAB",
                        level: "Mittelstufe"
                    }
                }
            },
            languages: {
                title: "Sprachen",
                items: {
                    russian: {
                        name: "Russisch",
                        level: "Muttersprache"
                    },
                    english: {
                        name: "Englisch",
                        level: "C2"
                    },
                    german: {
                        name: "Deutsch",
                        level: "B2"
                    },
                    slovenian: {
                        name: "Slowenisch",
                        level: "A2"
                    }
                }
            }
        },

        // Berufserfahrungen
        experience: {
            industry: {
                title: "Berufserfahrungen",
                positions: {
                    teamLead: {
                        title: "Teamleiter für die Erstellung von Anweisungen",
                        company: "Plow",
                        period: "02.2023 - 12.2023",
                        duties: [
                            "Interviews mit Kunden und Fachleuten",
                            "Erstellung der Kursstruktur (MindMeister, Miro)",
                            "Leitung der jüngeren Entwicklerteams für Anweisungen",
                            "Erstellung von Bewertungsinstrumenten"
                        ]
                    },
                    tutor: {
                        title: "Einzelunterricht für Fremdsprachen",
                        period: "2016 - 2023",
                        duties: [
                            "Verschiedene Altersgruppen",
                            "Interaktive Lernansätze",
                            "Vorbereitung auf IELTS und TOEFL"
                        ]
                    }
                }
            }
        },

        // Interfaces
        interface: {
            viewPaper: "Papier anzeigen",
            copyEmail: "Email kopiert in die Zwischenablage!",
            readMore: "Mehr lesen",
            showDetails: "Details anzeigen",
            hideDetails: "Details ausblenden",
            loading: "Laden...",
            contactMe: "Mich kontaktieren",
            downloadCV: "CV herunterladen",
            viewProfile: "Profil anzeigen"
        }
    },
    it: {
        // Заголовки
        title: "Assistente di ricerca · Linguistica",
        location: "Nova Gorica, Slovenia",
        university: "Università di Nova Gorica",
        
        // Навигация
        scholar: "Scholar",
        researchgate: "ResearchGate",
        linkedin: "LinkedIn",
        telegram: "Telegram",
        
        // Статистика
        conferenceTalks: "Interventi in conferenze",
        publications: "Pubblicazioni",
        languages: "Lingue",
        
        // Разделы
        researchFocus: "Area di ricerca",
        skillsExpertise: "Conoscenze e competenze",
        selectedPublications: "Pubblicazioni selezionate",
        
        // Навыки
        researchMethods: "Metodi di ricerca",
        statisticalAnalysis: "Analisi statistica",
        experimentalDesign: "Progettazione sperimentale",
        eegResearch: "Ricerca EEG",
        programming: "Programmazione",
        
        // Уровни владения
        native: "Linguaggio madre",
        advanced: "Avanzato",
        intermediate: "Intermedio",
        
        // Копирование
        copyEmail: "Email copiata negli appunti!",
        copy: "Copiare",

        // Статистика
        statsTalks: "Interventi in conferenze",
        statsPublications: "Pubblicazioni",
        statsLanguages: "Paesi",

        // Основные блоки
        researchInterests: {
            title: "Interessi di ricerca",
            description: "Il mio lavoro si concentra sulla psicolingustica, con un accento sulla sintassi, la struttura informativa e la fonologia. Specificamente, studio il cambiamento delle parole, il loro ordine e la sintassi dei particelli russi, così come la comprensione e la produzione della struttura informativa.",
            tags: [
                "Psicolingustica",
                "Sintassi",
                "Fonologia",
                "Struttura informativa"
            ]
        },

        methods: {
            title: "Metodi",
            description: "Nel studiare questi fenomeni linguistici, uso sia approcci sperimentali (comportamentali e nevrofisiciologici) che teorici. Le mie ricerche integrano diverse metodologie per studiare il processo di elaborazione linguistica e le sue strutture di base.",
            tags: [
                "Sperimentale",
                "Comportamentale",
                "Nevrofisico-logico",
                "Teorico"
            ]
        },

        dataAnalysis: {
            title: "Analisi dei dati e strumenti",
            description: "Uso strumenti moderni per la raccolta e l'analisi dei dati, inclusa R e RStudio per la modellazione statistica, Eyelink 1000 per i segnali di movimento degli occhi e BrainRecorder e BrainAnalyzer per esperimenti EEG. Lavoro anche con strumenti linguistici come UDPipe, Mystem, Praat e ELAN.",
            tags: [
                "R & RStudio",
                "Eyelink 1000",
                "BrainAnalyzer",
                "Praat",
                "ELAN"
            ]
        },

        // Pubblicazioni
        publications: {
            paper1: {
                title: "Il ruolo del modo di presentazione nel processamento delle frasi",
                description: "Uno studio sulla questione se il processamento auditivo è più o meno richiesto rispetto al processamento scritto, che mostra che il modo di presentazione influisce sul tempo di risposta, ma non sulla precisione di comprensione.",
                tags: ["Psicolingustica", "Processamento delle frasi", "Lingua russa"],
                year: "2023",
                publisher: "ExLing Society"
            },
            paper2: {
                title: "Sulla differenza tra la parabola e l'inversione",
                description: "Un'analisi delle differenze strutturali e psicolingustiche tra la parabola e l'inversione, che dimostra che questi fenomeni si differenziano sia nelle proprietà strutturali che nella complessità del processamento.",
                tags: ["Stilistica", "Sintassi", "Psicolingustica"],
                year: "2023",
                publisher: "Grammatica russa nel dialogo tra scuole scientifiche"
            },
            paper3: {
                title: "Test di comprensione delle frasi per il russo: strumento per la valutazione della competenza sintattica",
                description: "Sviluppo e validazione di un test completo per la valutazione della competenza sintattica in russo, con l'enfasi su diversi aspetti della comprensione e del processamento delle frasi.",
                tags: ["Psicolingustica", "Lingua russa", "Valutazione sintattica"],
                year: "2023",
                publisher: "Frontiers in Psychology"
            }
        },

        // Competenze
        skills: {
            research: {
                title: "Metodi di ricerca",
                items: {
                    statistical: {
                        name: "Analisi statistica",
                        level: "Avanzato"
                    },
                    experimental: {
                        name: "Progettazione sperimentale",
                        level: "Avanzato"
                    },
                    eeg: {
                        name: "Ricerca EEG",
                        level: "Intermedio"
                    }
                }
            },
            programming: {
                title: "Programmazione",
                items: {
                    python: {
                        name: "Python (NumPy, Pandas)",
                        level: "Avanzato"
                    },
                    r: {
                        name: "R (tidyverse, lme4)",
                        level: "Avanzato"
                    },
                    matlab: {
                        name: "MATLAB",
                        level: "Intermedio"
                    }
                }
            },
            languages: {
                title: "Lingue",
                items: {
                    russian: {
                        name: "Russo",
                        level: "Linguaggio madre"
                    },
                    english: {
                        name: "Inglese",
                        level: "C2"
                    },
                    german: {
                        name: "Tedesco",
                        level: "B2"
                    },
                    slovenian: {
                        name: "Sloveno",
                        level: "A2"
                    }
                }
            }
        },

        // Esperienza lavorativa
        experience: {
            industry: {
                title: "Esperienza lavorativa",
                positions: {
                    teamLead: {
                        title: "Leader del team per la creazione di istruzioni",
                        company: "Plow",
                        period: "02.2023 - 12.2023",
                        duties: [
                            "Interviste con clienti e esperti",
                            "Creazione della struttura del corso (MindMeister, Miro)",
                            "Guida del team di sviluppatori più giovani per le istruzioni",
                            "Creazione di strumenti di valutazione"
                        ]
                    },
                    tutor: {
                        title: "Tuteur individuel pour les langues étrangères",
                        period: "2016 - 2023",
                        duties: [
                            "Groupes d'âges différents",
                            "Approches interactives d'apprentissage",
                            "Préparation pour IELTS et TOEFL"
                        ]
                    }
                }
            }
        },

        // Interfaces
        interface: {
            viewPaper: "Visualizza articolo",
            copyEmail: "Email copiata negli appunti!",
            readMore: "Leggi di più",
            showDetails: "Mostra dettagli",
            hideDetails: "Nascondi dettagli",
            loading: "Caricamento...",
            contactMe: "Contattami",
            downloadCV: "Scarica CV",
            viewProfile: "Visualizza profilo"
        }
    },
    fr: {
        // Заголовки
        title: "Assistant de recherche · Linguistique",
        location: "Nova Gorica, Slovaquie",
        university: "Université de Nova Gorica",
        
        // Навигация
        scholar: "Scholar",
        researchgate: "ResearchGate",
        linkedin: "LinkedIn",
        telegram: "Telegram",
        
        // Статистика
        conferenceTalks: "Interventions en conférences",
        publications: "Publications",
        languages: "Langues",
        
        // Разделы
        researchFocus: "Domaine de recherche",
        skillsExpertise: "Compétences et connaissances",
        selectedPublications: "Publications sélectionnées",
        
        // Навыки
        researchMethods: "Méthodes de recherche",
        statisticalAnalysis: "Analyse statistique",
        experimentalDesign: "Conception expérimentale",
        eegResearch: "Recherches EEG",
        programming: "Programmation",
        
        // Уровни владения
        native: "Langue maternelle",
        advanced: "Avancé",
        intermediate: "Intermédiaire",
        
        // Копирование
        copyEmail: "Email copié dans le presse-papiers!",
        copy: "Copier",

        // Статистика
        statsTalks: "Interventions en conférences",
        statsPublications: "Publications",
        statsLanguages: "Pays",

        // Основные блоки
        researchInterests: {
            title: "Intérêts de recherche",
            description: "Mon travail se concentre sur la psycholinguistique, avec un accent sur la syntaxe, la structure informationnelle et la phonologie. Plus spécifiquement, je m'intéresse à la réorganisation des mots, à l'ordre des mots et à la syntaxe des particules russes, ainsi qu'à la compréhension et à la production de la structure informationnelle.",
            tags: [
                "Psycholinguistique",
                "Syntaxe",
                "Phonologie",
                "Structure informationnelle"
            ]
        },

        methods: {
            title: "Méthodes",
            description: "Je utilise à la fois des approches expérimentales (comportementales et nevrofisio-logiques) et théoriques pour étudier ces phénomènes linguistiques. Mes recherches intègrent diverses méthodologies pour étudier le processus d'élaboration linguistique et ses structures de base.",
            tags: [
                "Expérimental",
                "Comportemental",
                "Nevrofisio-logique",
                "Théorique"
            ]
        },

        dataAnalysis: {
            title: "Analyse des données et instruments",
            description: "Je utilise des instruments modernes pour collecter et analyser des données, y compris R et RStudio pour la modélisation statistique, Eyelink 1000 pour les signaux de mouvement des yeux et BrainRecorder et BrainAnalyzer pour les expériences EEG. Je travaille également avec des instruments linguistiques comme UDPipe, Mystem, Praat et ELAN.",
            tags: [
                "R & RStudio",
                "Eyelink 1000",
                "BrainAnalyzer",
                "Praat",
                "ELAN"
            ]
        },

        // Publications
        publications: {
            paper1: {
                title: "Le rôle du mode de présentation dans le traitement des phrases",
                description: "Une étude sur la question de savoir si le traitement auditif est plus ou moins exigeant par rapport au traitement écrit, qui montre que le mode de présentation influence les temps de réponse, mais pas la précision de la compréhension.",
                tags: ["Psycholinguistique", "Traitement des phrases", "Langue russe"],
                year: "2023",
                publisher: "ExLing Society"
            },
            paper2: {
                title: "Sur la différence entre la parabole et l'inversion",
                description: "Une analyse des différences structurelles et psycholinguistiques entre la parabole et l'inversion, qui montre que ces phénomènes se différencient à la fois dans les propriétés structurelles et dans la complexité du traitement.",
                tags: ["Stylistique", "Syntaxe", "Psycholinguistique"],
                year: "2023",
                publisher: "Grammaire russe dans le dialogue entre écoles scientifiques"
            },
            paper3: {
                title: "Test de compréhension des phrases pour le russe : outil d'évaluation de la compétence syntaxique",
                description: "Développement et validation d'un test complet pour évaluer la compétence syntaxique en russe, avec un accent sur divers aspects de la compréhension et du traitement des phrases.",
                tags: ["Psycholinguistique", "Langue russe", "Évaluation syntaxique"],
                year: "2023",
                publisher: "Frontiers in Psychology"
            }
        },

        // Compétences
        skills: {
            research: {
                title: "Méthodes de recherche",
                items: {
                    statistical: {
                        name: "Analyse statistique",
                        level: "Avancé"
                    },
                    experimental: {
                        name: "Conception expérimentale",
                        level: "Avancé"
                    },
                    eeg: {
                        name: "Recherches EEG",
                        level: "Intermédiaire"
                    }
                }
            },
            programming: {
                title: "Programmation",
                items: {
                    python: {
                        name: "Python (NumPy, Pandas)",
                        level: "Avancé"
                    },
                    r: {
                        name: "R (tidyverse, lme4)",
                        level: "Avancé"
                    },
                    matlab: {
                        name: "MATLAB",
                        level: "Intermédiaire"
                    }
                }
            },
            languages: {
                title: "Langues",
                items: {
                    russian: {
                        name: "Russe",
                        level: "Langue maternelle"
                    },
                    english: {
                        name: "Anglais",
                        level: "C2"
                    },
                    german: {
                        name: "Allemand",
                        level: "B2"
                    },
                    slovenian: {
                        name: "Slovène",
                        level: "A2"
                    }
                }
            }
        },

        // Expérience professionnelle
        experience: {
            industry: {
                title: "Expérience professionnelle",
                positions: {
                    teamLead: {
                        title: "Leader de l'équipe pour la création d'instructions",
                        company: "Plow",
                        period: "02.2023 - 12.2023",
                        duties: [
                            "Entrevues avec les clients et les spécialistes",
                            "Création de la structure du cours (MindMeister, Miro)",
                            "Direction de l'équipe des développeurs plus jeunes pour les instructions",
                            "Création d'instruments d'évaluation"
                        ]
                    },
                    tutor: {
                        title: "Tuteur individuel pour les langues étrangères",
                        period: "2016 - 2023",
                        duties: [
                            "Groupes d'âges différents",
                            "Approches interactives d'apprentissage",
                            "Préparation pour IELTS et TOEFL"
                        ]
                    }
                }
            }
        },

        // Interfaces
        interface: {
            viewPaper: "Afficher l'article",
            copyEmail: "Email copié dans le presse-papiers!",
            readMore: "Lire plus",
            showDetails: "Afficher les détails",
            hideDetails: "Masquer les détails",
            loading: "Chargement...",
            contactMe: "Me contacter",
            downloadCV: "Télécharger CV",
            viewProfile: "Afficher le profil"
        }
    }
};

class LanguageManager {
    constructor() {
        this.translations = translations;
        this.currentLang = localStorage.getItem('language') || 'en';
        this.fallbackLang = 'en';
        this.animationDuration = 300;
        this.init();
    }

    init() {
        this.createLanguageSwitcher();
        this.switchLanguage(this.currentLang, false);
    }

    createLanguageSwitcher() {
        const langSwitcher = document.createElement('div');
        langSwitcher.className = 'language-switcher';
        langSwitcher.innerHTML = `
            <button class="lang-btn ${this.currentLang === 'en' ? 'active' : ''}" data-lang="en">
                <span class="lang-icon">🇬🇧</span>
                <span class="lang-text">EN</span>
            </button>
            <button class="lang-btn ${this.currentLang === 'sl' ? 'active' : ''}" data-lang="sl">
                <span class="lang-icon">🇸🇮</span>
                <span class="lang-text">SL</span>
            </button>
        `;

        langSwitcher.querySelectorAll('.lang-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleLanguageChange(e));
        });

        const navContainer = document.querySelector('.nav-container');
        if (navContainer) {
            navContainer.appendChild(langSwitcher);
        }
    }

    async handleLanguageChange(e) {
        const newLang = e.currentTarget.getAttribute('data-lang');
        if (newLang === this.currentLang) return;

        document.body.classList.add('language-transition');
        await this.fadeOut();
        this.switchLanguage(newLang);
        await this.fadeIn();
        document.body.classList.remove('language-transition');
    }

    async fadeOut() {
        const content = document.querySelector('.container');
        if (!content) return;
        content.style.opacity = '0';
        await new Promise(resolve => setTimeout(resolve, this.animationDuration));
    }

    async fadeIn() {
        const content = document.querySelector('.container');
        if (!content) return;
        content.style.opacity = '1';
        await new Promise(resolve => setTimeout(resolve, this.animationDuration));
    }

    switchLanguage(lang) {
        this.currentLang = lang;
        document.documentElement.setAttribute('lang', lang);
        localStorage.setItem('language', lang);
        this.updateAllTranslations();
        this.updateActiveButton();
    }

    updateAllTranslations() {
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            const translation = this.getTranslation(key);
            if (translation) {
                element.textContent = translation;
            }
        });
    }

    getTranslation(key) {
        return this.translations[this.currentLang][key] || this.translations[this.fallbackLang][key];
    }

    updateActiveButton() {
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.classList.toggle('active', btn.getAttribute('data-lang') === this.currentLang);
        });
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    window.languageManager = new LanguageManager();
}); 