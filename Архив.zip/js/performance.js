// Используем requestAnimationFrame для анимаций
function animate() {
    requestAnimationFrame(() => {
        // Анимация
        if (!document.hidden) {
            animate();
        }
    });
}

// Оптимизируем обработчики событий
const throttle = (func, limit) => {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}; 