document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('themeToggle');
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    
    // Функция для установки темы
    const setTheme = (theme) => {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        
        // Обновляем состояние кнопки
        const isDark = theme === 'dark';
        themeToggle.setAttribute('aria-checked', isDark.toString());
        
        // Обновляем цвет темы в мета-теге
        document.querySelector('meta[name="theme-color"]')
            .setAttribute('content', isDark ? '#0f172a' : '#ffffff');
    };

    // Проверяем сохраненную тему или системные настройки
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        setTheme(savedTheme);
    } else if (prefersDarkScheme.matches) {
        setTheme('dark');
    } else {
        setTheme('light');
    }

    // Обработчик клика по кнопке
    themeToggle.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        // Добавляем класс для анимации перехода
        document.documentElement.classList.add('theme-transition');
        
        // Устанавливаем новую тему
        setTheme(newTheme);
        
        // Удаляем класс анимации после завершения перехода
        setTimeout(() => {
            document.documentElement.classList.remove('theme-transition');
        }, 300);
    });

    // Следим за системными настройками
    prefersDarkScheme.addEventListener('change', (e) => {
        const newTheme = e.matches ? 'dark' : 'light';
        setTheme(newTheme);
    });
}); 