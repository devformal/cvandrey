document.addEventListener('DOMContentLoaded', () => {
    const emailLink = document.querySelector('.detail-link');
    const toast = document.getElementById('copyToast');
    
    emailLink.addEventListener('click', async (e) => {
        e.preventDefault();
        const email = emailLink.querySelector('.email-text').textContent;
        
        try {
            await navigator.clipboard.writeText(email);
            
            // Добавляем класс copied для анимации кнопки
            emailLink.classList.add('copied');
            
            // Показываем уведомление
            toast.classList.add('show');
            
            // Удаляем классы после анимации
            setTimeout(() => {
                emailLink.classList.remove('copied');
                toast.classList.remove('show');
            }, 3000);
            
        } catch (err) {
            console.error('Failed to copy:', err);
        }
    });
});

// Добавим обработку ошибок
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showToast('Copied to clipboard!');
    } catch (err) {
        showToast('Failed to copy', 'error');
        console.error('Copy failed:', err);
    }
}

// Улучшим доступность
function showToast(message, type = 'success') {
    const toast = document.getElementById('copyToast');
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'polite');
    // ...
} 