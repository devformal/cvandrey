import { StateManager } from './services/StateManager.js';
import { EventBus } from './utils/EventBus.js';
import { Logger } from './services/Logger.js';
import { AnimationController } from './modules/animations.js';
import { performanceUtils } from './utils/performance.js';
import { AvatarController } from './modules/AvatarController.js';
import { ScrollProgressController } from './modules/ScrollProgressController.js';
import { AppConfig } from './config/AppConfig.js';
import { Store } from './store/Store.js';

export class App {
    constructor() {
        // Инициализируем конфигурацию первой
        this.config = new AppConfig();

        // Проверяем поддержку необходимых API
        this.checkBrowserSupport();

        // Инициализация основных сервисов
        this.state = new StateManager();
        this.events = new EventBus();
        this.logger = new Logger({
            prefix: this.config.get('app.name'),
            level: this.config.get('errors.logLevel')
        });
        this.animations = new AnimationController();

        // Кэширование DOM элементов
        this.domElements = this.cacheDOMElements();

        // Инициализация модулей
        this.initializeModules();

        // Подписка на события
        this.bindEvents();

        // Создаем и инициализируем Store
        this.store = new Store(this);

        // Подписываемся на изменения
        this.store.subscribe((namespace, newState, oldState) => {
            switch (namespace) {
                case 'theme':
                    this.applyTheme(newState);
                    break;
                case 'locale':
                    this.applyLocale(newState);
                    break;
            }
        });
    }

    cacheDOMElements() {
        return {
            avatar: document.querySelector('.profile-avatar'),
            emailLink: document.querySelector('.detail-link'),
            toast: document.getElementById('copyToast'),
            themeToggle: document.getElementById('themeToggle'),
            scrollProgress: document.querySelector('.scroll-progress')
        };
    }

    initializeModules() {
        this.avatarController = new AvatarController(this);
        this.scrollProgress = new ScrollProgressController(this);
        
        // Инициализация анимаций
        this.animations.add('avatar', () => {
            // Логика анимации аватара
        });

        this.animations.add('scroll-progress', () => {
            // Логика анимации прогресс-бара
        });

        // Установка начального состояния
        this.state.state.theme = localStorage.getItem('theme') || 'light';
        this.state.state.language = localStorage.getItem('language') || 'en';
    }

    bindEvents() {
        // Оптимизированные обработчики событий
        const handleScroll = performanceUtils.throttle(() => {
            const scrolled = window.scrollY / (document.documentElement.scrollHeight - window.innerHeight);
            this.state.state.scrollProgress = scrolled * 100;
        }, 16); // ~60fps

        const handleResize = performanceUtils.debounce(() => {
            this.events.emit('viewport:resize', {
                width: window.innerWidth,
                height: window.innerHeight
            });
        }, 150);

        // Подписка на изменения состояния
        this.state.subscribe('theme', (newTheme) => {
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            this.events.emit('theme:changed', newTheme);
        });

        this.state.subscribe('language', (newLang) => {
            document.documentElement.setAttribute('lang', newLang);
            localStorage.setItem('language', newLang);
            this.events.emit('language:changed', newLang);
        });

        // DOM события
        window.addEventListener('scroll', handleScroll, { passive: true });
        window.addEventListener('resize', handleResize, { passive: true });

        // Обработка ошибок
        window.addEventListener('error', (event) => {
            this.logger.log(Logger.levels.ERROR, 'Global error:', event.error);
            this.events.emit('error:global', event.error);
        });

        // Очистка при уничтожении
        window.addEventListener('unload', () => {
            this.destroy();
        });
    }

    destroy() {
        // Очистка ресурсов
        this.animations.stop();
        this.events.emit('app:destroy');
        
        // Очистка обработчиков
        window.removeEventListener('scroll', this.handleScroll);
        window.removeEventListener('resize', this.handleResize);

        this.avatarController.destroy();
        this.scrollProgress.destroy();
    }

    // Публичные методы
    setTheme(theme) {
        this.state.state.theme = theme;
    }

    setLanguage(lang) {
        this.state.state.language = lang;
    }

    checkBrowserSupport() {
        const required = {
            'IntersectionObserver': 'IntersectionObserver',
            'CSS Custom Properties': window.CSS && CSS.supports('color', 'var(--color)'),
            'CSS Grid': CSS.supports('display', 'grid'),
            'Fetch API': 'fetch' in window
        };

        const unsupported = Object.entries(required)
            .filter(([_, support]) => !support)
            .map(([name]) => name);

        if (unsupported.length > 0) {
            console.warn(`Browser doesn't support: ${unsupported.join(', ')}`);
            this.showBrowserWarning(unsupported);
        }
    }

    showBrowserWarning(unsupported) {
        // Показываем предупреждение о необходимости обновить браузер
    }

    applyTheme(newTheme) {
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        this.events.emit('theme:changed', newTheme);
    }

    applyLocale(newLang) {
        document.documentElement.setAttribute('lang', newLang);
        localStorage.setItem('language', newLang);
        this.events.emit('language:changed', newLang);
    }
} 