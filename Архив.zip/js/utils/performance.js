export const performanceUtils = {
    // Улучшенный debounce с возможностью отмены
    debounce(func, wait, immediate = false) {
        let timeout;
        let previousArgs;

        const debounced = function(...args) {
            previousArgs = args;

            const later = () => {
                timeout = null;
                if (!immediate) func.apply(this, previousArgs);
            };

            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);

            if (callNow) func.apply(this, args);
        };

        debounced.cancel = () => {
            clearTimeout(timeout);
            timeout = null;
        };

        return debounced;
    },

    // Улучшенный throttle с trailing/leading options
    throttle(func, limit, options = { leading: true, trailing: true }) {
        let timeout;
        let previous = 0;

        return function throttled(...args) {
            const now = Date.now();

            if (!previous && !options.leading) {
                previous = now;
            }

            const remaining = limit - (now - previous);

            if (remaining <= 0 || remaining > limit) {
                if (timeout) {
                    clearTimeout(timeout);
                    timeout = null;
                }
                previous = now;
                func.apply(this, args);
            } else if (!timeout && options.trailing) {
                timeout = setTimeout(() => {
                    previous = options.leading ? Date.now() : 0;
                    timeout = null;
                    func.apply(this, args);
                }, remaining);
            }
        };
    }
}; 