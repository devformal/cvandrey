#!/bin/bash

# Очищаем кэш фавиконов
echo "🗑️ Очистка кэша фавиконов..."
./scripts/cleanup.sh

# Генерируем новые фавиконы
echo "🔄 Генерация новых фавиконов..."
./scripts/generate_favicons.sh

# Обновляем временную метку в HTML
echo "📝 Обновление временной метки..."
current_time=$(date +%s)
sed -i.bak "s/favicon\.svg?v=[0-9]*/favicon.svg?v=$current_time/g" index.html
sed -i.bak "s/favicon\.png?v=[0-9]*/favicon.png?v=$current_time/g" index.html
sed -i.bak "s/apple-touch-icon\.png?v=[0-9]*/apple-touch-icon.png?v=$current_time/g" index.html

# Очищаем временные файлы
rm -f index.html.bak

echo "✨ Фавиконы успешно обновлены" 