#!/bin/bash

# Минимизируем вывод в консоль
exec > /dev/null 2>&1

# Удаляем дублирующиеся проверки инструментов
required_tools=("cwebp" "jpegoptim" "optipng" "svgo")

for tool in "${required_tools[@]}"; do
    command -v $tool >/dev/null 2>&1 || { 
        echo >&2 "$tool не установлен. Установите через соответствующий пакетный менеджер"; 
        exit 1; 
    }
done

# Оптимизация изображений
find ./images -type f \( -iname "*.jpg" -o -iname "*.png" -o -iname "*.svg" \) | while read -r img; do
    ext="${img##*.}"
    case "$ext" in
        jpg|jpeg)
            jpegoptim --max=85 --strip-all "$img"
            cwebp -q 80 "$img" -o "${img%.*}.webp"
            ;;
        png)
            optipng -o7 "$img"
            cwebp -q 80 "$img" -o "${img%.*}.webp"
            ;;
        svg)
            svgo "$img"
            ;;
    esac
done

echo "✅ Оптимизация изображений завершена" 