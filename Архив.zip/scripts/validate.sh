#!/bin/bash

# Проверяем HTML
html5validator index.html

# Проверяем CSS
stylelint "styles.css" 