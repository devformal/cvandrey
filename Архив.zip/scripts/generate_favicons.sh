#!/bin/bash

# Минимизируем вывод в консоль
exec > /dev/null 2>&1

# Удаляем дублирующиеся проверки инструментов
command -v inkscape >/dev/null 2>&1 || { 
    echo >&2 "Требуется inkscape. Установите через brew install inkscape"; 
    exit 1; 
}

command -v optipng >/dev/null 2>&1 || { 
    echo >&2 "Требуется optipng. Установите через brew install optipng"; 
    exit 1; 
}

# Генерация фавиконов
sizes=(16 32 48 96 144 192 512)
output_dir="public/favicons"

mkdir -p $output_dir

for size in "${sizes[@]}"; do
    output_file="$output_dir/favicon-${size}x${size}.png"
    inkscape -w $size -h $size public/favicon.svg -o "$output_file"
    optipng -o7 "$output_file"
done

# Копируем основные фавиконы
cp "$output_dir/favicon-32x32.png" "public/favicon.png"
cp "$output_dir/favicon-192x192.png" "public/apple-touch-icon.png"

echo "✅ Фавиконы сгенерированы" 