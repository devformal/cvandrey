#!/bin/bash

# Удаляем файл helpers.css
rm -f css/utils/helpers.css

echo "✅ Файл helpers.css успешно удален"