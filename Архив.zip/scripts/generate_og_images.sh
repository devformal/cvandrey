#!/bin/bash

# Проверяем наличие необходимых инструментов
command -v convert >/dev/null 2>&1 || { echo >&2 "Требуется ImageMagick. Установите через brew install imagemagick"; exit 1; }

# Создаем директорию для OG изображений
mkdir -p public/images

# Генерируем OG изображение
convert -size 1200x630 xc:white \
    -font "Helvetica" \
    -pointsize 60 \
    -gravity center \
    -annotate +0-100 "Andrey Maksimov" \
    -pointsize 40 \
    -annotate +0+0 "Senior Project Manager & System Analyst" \
    -fill "#3b82f6" \
    -draw "rectangle 0,580 1200,630" \
    public/images/og-image.jpg

# Генерируем Twitter Card изображение (немного другой формат)
convert -size 1200x600 xc:white \
    -font "Helvetica" \
    -pointsize 60 \
    -gravity center \
    -annotate +0-100 "Andrey Maksimov" \
    -pointsize 40 \
    -annotate +0+0 "Senior Project Manager & System Analyst" \
    -fill "#3b82f6" \
    -draw "rectangle 0,550 1200,600" \
    public/images/twitter-card.jpg

# Оптимизируем изображения
jpegoptim --max=85 public/images/og-image.jpg
jpegoptim --max=85 public/images/twitter-card.jpg

echo "✨ OG изображения сгенерированы" 