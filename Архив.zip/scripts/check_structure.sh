#!/bin/bash

# Проверяем наличие необходимых директорий
required_dirs=(
    "images"
    "images/avatar"
    "images/app-icons"
    "images/research"
)

for dir in "${required_dirs[@]}"; do
    if [ ! -d "$dir" ]; then
        mkdir -p "$dir"
        echo "Created directory: $dir"
    fi
done 