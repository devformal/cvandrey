const CACHE_VERSION = 'v1';
const CACHE_NAME = `portfolio-${CACHE_VERSION}`;

// Ресурсы для предварительного кэширования
const PRECACHE_URLS = [
    '/',
    '/index.html',
    '/css/base/reset.css',
    '/css/themes/colors.css',
    '/css/components/cards.css',
    '/css/components/buttons.css',
    '/css/components/navigation.css',
    '/css/utils/animations.css',
    '/css/utils/helpers.css',
    '/js/theme.js',
    '/js/analytics.js',
    '/js/pwa.js',
    '/images/avatar/foto_andrei.jpg',
    '/images/app-icons/itmo_black.png',
    '/images/app-icons/itmo_white.png',
    '/images/app-icons/linkedn.svg',
    '/images/app-icons/telegram2.svg',
    'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap'
];

// Установка Service Worker
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => cache.addAll(PRECACHE_URLS))
            .then(() => self.skipWaiting())
    );
});

// Активация Service Worker
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames
                        .filter(cacheName => cacheName.startsWith('portfolio-'))
                        .filter(cacheName => cacheName !== CACHE_NAME)
                        .map(cacheName => caches.delete(cacheName))
                );
            })
            .then(() => self.clients.claim())
    );
});

// Стратегия кэширования: Network First с fallback на Cache
self.addEventListener('fetch', event => {
    // Пропускаем запросы к Google Analytics
    if (event.request.url.includes('google-analytics.com')) {
        return;
    }

    event.respondWith(
        fetch(event.request)
            .then(response => {
                // Кэшируем успешные ответы
                if (response.ok) {
                    const responseClone = response.clone();
                    caches.open(CACHE_NAME)
                        .then(cache => cache.put(event.request, responseClone));
                }
                return response;
            })
            .catch(() => {
                // При ошибке сети используем кэш
                return caches.match(event.request)
                    .then(response => {
                        if (response) {
                            return response;
                        }
                        // Если ресурс не найден в кэше, возвращаем offline page
                        if (event.request.mode === 'navigate') {
                            return caches.match('/offline.html');
                        }
                        return new Response('Network error happened', {
                            status: 408,
                            headers: new Headers({
                                'Content-Type': 'text/plain'
                            })
                        });
                    });
            })
    );
});

// Периодическое обновление кэша
self.addEventListener('periodicsync', event => {
    if (event.tag === 'update-cache') {
        event.waitUntil(
            caches.open(CACHE_NAME)
                .then(cache => {
                    return Promise.all(
                        PRECACHE_URLS.map(url =>
                            fetch(url)
                                .then(response => cache.put(url, response))
                                .catch(error => console.log(`Failed to update cache for ${url}:`, error))
                        )
                    );
                })
        );
    }
}); 