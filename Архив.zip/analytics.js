if (typeof gtag !== 'undefined') {
    // код использующий gtag
} 